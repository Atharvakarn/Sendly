# Build Sendly from an Android phone

Sendly does not require AndroidIDE or a local Android SDK. GitHub Actions can compile the APK in the cloud while you work entirely from your phone browser.

## Files to upload

1. `Sendly-v0.1.0-beta1-source.zip`
2. `build-sendly.yml`, created in the repository as `.github/workflows/build-sendly.yml`

## GitHub steps

1. Create a GitHub repository.
2. Upload `Sendly-v0.1.0-beta1-source.zip` to the repository root.
3. Create `.github/workflows/build-sendly.yml` and paste the supplied workflow into it.
4. Commit both files.
5. Open **Actions** > **Build Sendly APK**.
6. Run the workflow if it did not start automatically.
7. When it completes, download the **Sendly-v0.1.0-beta1** artifact.
8. Extract the artifact ZIP and install `Sendly-v0.1.0-beta1.apk` on Android.

The debug APK produced by Android's build system is signed with a debug key and is directly installable for testing.

## First test

1. Turn on Wi-Fi and Bluetooth on both devices.
2. On the Mac set AirDrop to **Everyone for 10 Minutes**.
3. Open Sendly.
4. Start with one small JPEG.
5. If discovery or transfer fails, open **Diagnostics** in Sendly and share the log.
