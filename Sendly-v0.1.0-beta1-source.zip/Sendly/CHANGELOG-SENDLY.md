# Sendly 0.1.0-beta1

Target: Nothing Phone (1), Android 15, sending to macOS AirDrop receivers.

## Compatibility changes

- Removed IPv4-only AirDrop discovery and added IPv6/link-local discovery.
- Added interface scope handling for IPv6 AirDrop HTTPS connections.
- Added persistent diagnostics visible and shareable directly from the phone.
- Added modern AirDrop `TransferID` session binding across `/Ask` and `/Upload`.
- Added modern transfer metadata and `application/x-dvzip` payload generation.
- Kept the older gzip/CPIO transfer format behind a **Legacy transfer payload** toggle.
- Simplified BLE to the sender advertisement path.
- Removed obsolete receiving, Nearby Share, Wi-Fi Direct, media/storage permission, and server-certificate code.
- Updated the Android project for API 34 / JDK 17 / Gradle 8.2 / Android Gradle Plugin 8.2.2.
- Rebranded the app to **Sendly** and recolored the original icon system from yellow to `#E90130`.
- Changed application ID to `com.sendly.transfer` so beta builds can coexist with the original WarpShare app.

## Beta expectation

This build is deliberately diagnostic. Current AirDrop uses private Apple protocols and behavior can differ by macOS version and Wi-Fi/Bluetooth hardware. The in-app Diagnostics screen is part of the test loop, not an optional extra.
