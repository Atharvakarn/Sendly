# Sendly

Experimental Android-to-macOS AirDrop-compatible sender, derived from the Apache-2.0 WarpShare 2.0.4 codebase.

**Target beta:** Nothing Phone (1), Android 15 / Nothing OS 3.x, sending to macOS AirDrop receivers.

## Why this branch exists

The archived WarpShare code assumes older AirDrop discovery and upload behavior. Sendly keeps the original user flow but updates the sender around the compatibility problems most likely to affect newer macOS versions:

- IPv6/link-local AirDrop discovery instead of IPv4-only discovery
- modern `/Ask` + `/Upload` TransferID session binding
- modern `application/x-dvzip` payload support
- current upload metadata
- Android 12+ Bluetooth/Nearby-device permissions
- phone-readable diagnostics, so testing does not require ADB or a computer

A legacy gzip/CPIO upload option remains in Settings for older macOS tests.

## Status

`0.1.0-beta1` is a diagnostic compatibility build. AirDrop is a private Apple protocol, so the code must be validated against real Macs before it should be considered stable.

## Build without a computer

See [`BUILD_ON_PHONE.md`](BUILD_ON_PHONE.md). The recommended phone-only route is GitHub Actions cloud compilation. No Android IDE is required on the phone.

## First test

1. Enable Wi-Fi and Bluetooth on the Android phone and Mac.
2. Set AirDrop on the Mac to **Everyone for 10 Minutes** (or **Everyone** on older macOS).
3. Open Sendly and wait for the Mac to appear.
4. Send a small JPEG first.
5. If discovery or transfer fails, open **Diagnostics** and share the log.

## License

Apache License 2.0, inherited from the original project. See `LICENSE`.

AirDrop is a trademark of Apple Inc. This project is not affiliated with Apple.
