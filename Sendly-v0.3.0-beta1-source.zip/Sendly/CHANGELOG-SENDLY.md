# Sendly changelog

## 0.3.0-beta1

- Replaced experimental native AirDrop discovery with reliable browser receiver mode.
- No Mac app installation required.
- Direct local HTTP transfer over the same Wi-Fi network or phone hotspot.
- Added Photos & videos and Files selection flow.
- Added Android share-sheet support directly into Sendly.
- Added local receiver link with Copy Link action.
- Nearby Devices now reports when a Mac browser connects.
- Added browser-side Sendly download page using brand accent #E90130.
- Kept persistent diagnostics for testing.
- Files remain local and are not uploaded to a cloud service.
