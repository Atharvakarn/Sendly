# Sendly

Sendly transfers files from Android to macOS without installing anything on the Mac.

## v0.3 browser receiver mode

1. Choose **Photos & videos** or **Files** in Sendly.
2. Sendly shows a local address such as `http://192.168.1.25:8765`.
3. Open that address in Safari, Chrome, Edge or Firefox on the Mac.
4. Download the selected files directly from the phone.

The phone and Mac must be on the same local network. If no Wi-Fi router is available, connect the Mac to the phone's hotspot.

No cloud upload, account, or macOS companion application is required.

### Why browser mode?

Modern AirDrop uses Apple's AWDL peer-to-peer Wi-Fi layer. Ordinary Android applications cannot reliably access or emulate that interface on typical unrooted Android hardware. Browser receiver mode uses standard local HTTP instead, which is stable across Android and macOS versions.

## Build

```bash
./gradlew assembleDebug
```

Debug APK:

`app/build/outputs/apk/debug/app-debug.apk`

Sendly is an independent project and is not affiliated with Apple Inc.
