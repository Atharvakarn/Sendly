package com.sendly.transfer;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import fi.iki.elonen.NanoHTTPD;

import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;

/**
 * A tiny HTTP server that exposes the currently selected Android files to a browser on the
 * same local network. The Mac needs no companion application; Safari/Chrome is the receiver.
 */
public final class LocalTransferServer extends NanoHTTPD {

    public interface Listener {
        void onClientSeen(String label);
        void onFileRequested(String name);
    }

    public static final int DEFAULT_PORT = 8765;

    private final Context context;
    private final List<SharedItem> items = Collections.synchronizedList(new ArrayList<>());
    private volatile Listener listener;
    private volatile String lastClientLabel;

    public LocalTransferServer(Context context, int port) {
        super(port);
        this.context = context.getApplicationContext();
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setUris(List<Uri> uris) {
        synchronized (items) {
            items.clear();
            for (Uri uri : uris) {
                if (uri != null) items.add(SharedItem.from(context, uri));
            }
        }
        Diagnostics.log("WEB", "Updated browser share with " + items.size() + " item(s)");
    }

    public int getItemCount() {
        return items.size();
    }

    public String getLastClientLabel() {
        return lastClientLabel;
    }

    @Override
    public Response serve(IHTTPSession session) {
        noteClient(session);
        String uri = session.getUri();

        if ("/".equals(uri)) {
            return htmlResponse(renderHome());
        }

        if (uri != null && uri.startsWith("/file/")) {
            try {
                int index = Integer.parseInt(uri.substring("/file/".length()));
                SharedItem item;
                synchronized (items) {
                    if (index < 0 || index >= items.size()) return textResponse(Response.Status.NOT_FOUND, "File not found");
                    item = items.get(index);
                }
                InputStream input = context.getContentResolver().openInputStream(item.uri);
                if (input == null) return textResponse(Response.Status.NOT_FOUND, "File unavailable");

                Listener l = listener;
                if (l != null) l.onFileRequested(item.name);
                Diagnostics.log("WEB", "Browser requested file: " + item.name);

                Response response = item.size >= 0
                        ? newFixedLengthResponse(Response.Status.OK, item.mime, input, item.size)
                        : newChunkedResponse(Response.Status.OK, item.mime, input);
                String encoded = URLEncoder.encode(item.name, StandardCharsets.UTF_8.name()).replace("+", "%20");
                response.addHeader("Content-Disposition", "attachment; filename=\"" + safeAsciiFilename(item.name)
                        + "\"; filename*=UTF-8''" + encoded);
                response.addHeader("Cache-Control", "no-store");
                return response;
            } catch (NumberFormatException | IOException e) {
                Diagnostics.log("WEB", "File request failed: " + e);
                return textResponse(Response.Status.INTERNAL_ERROR, "Could not open this file");
            }
        }

        if ("/health".equals(uri)) {
            return textResponse(Response.Status.OK, "Sendly OK");
        }

        return textResponse(Response.Status.NOT_FOUND, "Not found");
    }

    private void noteClient(IHTTPSession session) {
        String ua = session.getHeaders().get("user-agent");
        String label = describeUserAgent(ua);
        lastClientLabel = label;
        Listener l = listener;
        if (l != null) l.onClientSeen(label);
        Diagnostics.log("WEB", "Receiver connected: " + label);
    }

    private String renderHome() {
        List<SharedItem> snapshot;
        synchronized (items) {
            snapshot = new ArrayList<>(items);
        }

        StringBuilder cards = new StringBuilder();
        if (snapshot.isEmpty()) {
            cards.append("<div class='empty'><strong>No files selected yet.</strong><br>Choose Photos &amp; videos or Files in Sendly on your phone, then refresh this page.</div>");
        } else {
            for (int i = 0; i < snapshot.size(); i++) {
                SharedItem item = snapshot.get(i);
                cards.append("<div class='file'><div class='meta'><div class='name'>")
                        .append(escapeHtml(item.name))
                        .append("</div><div class='size'>")
                        .append(escapeHtml(humanSize(item.size)))
                        .append("</div></div><a class='download' href='/file/")
                        .append(i)
                        .append("'>Download</a></div>");
            }
        }

        return "<!doctype html><html><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<title>Sendly</title><style>"
                + ":root{color-scheme:light dark;--accent:#E90130;--bg:#0b0b0d;--card:#17171a;--text:#f5f5f7;--muted:#a2a2aa;}"
                + "*{box-sizing:border-box}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:var(--bg);color:var(--text)}"
                + ".wrap{max-width:760px;margin:0 auto;padding:48px 24px 72px}.brand{display:flex;align-items:center;gap:12px;margin-bottom:42px}"
                + ".mark{width:34px;height:34px;border-radius:10px;background:var(--accent);display:grid;place-items:center;font-weight:800}.brand b{font-size:24px}"
                + "h1{font-size:38px;line-height:1.08;margin:0 0 10px}.lead{color:var(--muted);font-size:17px;line-height:1.5;margin:0 0 30px}"
                + ".file,.empty{background:var(--card);border:1px solid #29292f;border-radius:16px;padding:18px;margin:12px 0}.file{display:flex;align-items:center;gap:18px}.meta{min-width:0;flex:1}.name{font-weight:650;overflow-wrap:anywhere}.size{color:var(--muted);font-size:13px;margin-top:5px}.download{background:var(--accent);color:white;text-decoration:none;font-weight:650;padding:10px 15px;border-radius:10px;white-space:nowrap}"
                + ".empty{color:var(--muted);line-height:1.5}.empty strong{color:var(--text)}.foot{margin-top:30px;color:var(--muted);font-size:13px;line-height:1.5}"
                + "@media(max-width:520px){.wrap{padding:30px 16px}h1{font-size:30px}.file{align-items:flex-start;flex-direction:column}.download{width:100%;text-align:center}}"
                + "</style></head><body><main class='wrap'><div class='brand'><div class='mark'>S</div><b>Sendly</b></div>"
                + "<h1>Files from your phone</h1><p class='lead'>Direct local transfer. Nothing is uploaded to the cloud.</p>"
                + cards
                + "<div class='foot'>Keep Sendly open on the phone while downloading. Your Mac and phone must be on the same Wi-Fi network, or the Mac can join the phone's hotspot.</div>"
                + "</main></body></html>";
    }

    private Response htmlResponse(String body) {
        Response r = newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", body);
        r.addHeader("Cache-Control", "no-store");
        return r;
    }

    private Response textResponse(Response.Status status, String body) {
        return newFixedLengthResponse(status, "text/plain; charset=utf-8", body);
    }

    public static List<String> localIpv4Addresses() {
        List<String> preferred = new ArrayList<>();
        List<String> fallback = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces == null) return preferred;
            while (interfaces.hasMoreElements()) {
                NetworkInterface nif = interfaces.nextElement();
                if (!nif.isUp() || nif.isLoopback()) continue;
                String interfaceName = nif.getName() == null ? "" : nif.getName().toLowerCase(Locale.US);
                boolean wifiLike = interfaceName.startsWith("wlan") || interfaceName.startsWith("ap")
                        || interfaceName.startsWith("swlan") || interfaceName.startsWith("wifi");
                boolean tunnelLike = interfaceName.startsWith("tun") || interfaceName.startsWith("vpn")
                        || interfaceName.startsWith("wg");
                Enumeration<InetAddress> addresses = nif.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress address = addresses.nextElement();
                    if (address instanceof Inet4Address && !address.isLoopbackAddress() && address.isSiteLocalAddress()) {
                        String host = address.getHostAddress();
                        if (wifiLike) preferred.add(host);
                        else if (!tunnelLike) fallback.add(host);
                    }
                }
            }
        } catch (Exception e) {
            Diagnostics.log("WEB", "Could not enumerate local addresses: " + e);
        }
        preferred.addAll(fallback);
        return preferred;
    }

    private static String describeUserAgent(String ua) {
        if (ua == null || ua.isEmpty()) return "Browser connected";
        String lower = ua.toLowerCase(Locale.US);
        boolean mac = lower.contains("macintosh") || lower.contains("mac os x");
        String browser;
        if (lower.contains("edg/")) browser = "Edge";
        else if (lower.contains("chrome/") || lower.contains("crios/")) browser = "Chrome";
        else if (lower.contains("firefox/") || lower.contains("fxios/")) browser = "Firefox";
        else if (lower.contains("safari/") && lower.contains("version/")) browser = "Safari";
        else browser = "browser";
        return (mac ? "Mac · " : "") + browser + " connected";
    }

    private static String safeAsciiFilename(String name) {
        return name.replaceAll("[^A-Za-z0-9._ -]", "_").replace("\"", "_");
    }

    private static String escapeHtml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    private static String humanSize(long bytes) {
        if (bytes < 0) return "Ready to download";
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"KB", "MB", "GB", "TB"};
        int unit = -1;
        do {
            value /= 1024.0;
            unit++;
        } while (value >= 1024 && unit < units.length - 1);
        return String.format(Locale.US, value >= 10 ? "%.0f %s" : "%.1f %s", value, units[unit]);
    }

    private static final class SharedItem {
        final Uri uri;
        final String name;
        final String mime;
        final long size;

        private SharedItem(Uri uri, String name, String mime, long size) {
            this.uri = uri;
            this.name = name;
            this.mime = mime;
            this.size = size;
        }

        static SharedItem from(Context context, Uri uri) {
            ContentResolver resolver = context.getContentResolver();
            String name = null;
            long size = -1;
            try (Cursor cursor = resolver.query(uri, new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                    if (nameIndex >= 0) name = cursor.getString(nameIndex);
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex);
                }
            } catch (Exception ignored) {
            }
            if (name == null || name.trim().isEmpty()) name = uri.getLastPathSegment();
            if (name == null || name.trim().isEmpty()) name = "file";
            String mime = resolver.getType(uri);
            if (mime == null || mime.isEmpty()) mime = "application/octet-stream";
            return new SharedItem(uri, name, mime, size);
        }
    }
}
