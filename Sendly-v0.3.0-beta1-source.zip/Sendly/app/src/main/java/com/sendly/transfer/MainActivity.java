package com.sendly.transfer;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

/** Main Sendly UI for browser-based local transfer. */
public class MainActivity extends AppCompatActivity implements LocalTransferServer.Listener {

    private final List<Uri> pendingUris = new ArrayList<>();

    private TextView selectionStatus;
    private TextView serverAddress;
    private TextView connectionStatus;
    private TextView networkHint;
    private MaterialButton copyLink;

    private LocalTransferServer server;
    private String receiverUrl;

    private final ActivityResultLauncher<Intent> picker = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    collectUris(result.getData(), true);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        selectionStatus = findViewById(R.id.selection_status);
        serverAddress = findViewById(R.id.server_address);
        connectionStatus = findViewById(R.id.connection_status);
        networkHint = findViewById(R.id.network_hint);
        copyLink = findViewById(R.id.copy_link);

        findViewById(R.id.add_media).setOnClickListener(v -> openPicker(true));
        findViewById(R.id.add_files).setOnClickListener(v -> openPicker(false));
        findViewById(R.id.find_nearby).setOnClickListener(v -> refreshConnectionState(true));
        copyLink.setOnClickListener(v -> copyReceiverLink());

        startLocalReceiver();
        handleIncomingShare(getIntent());
        updateSelectionStatus();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingShare(intent);
    }

    @Override
    protected void onDestroy() {
        if (server != null) {
            server.setListener(null);
            server.stop();
            Diagnostics.log("WEB", "Local receiver stopped");
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.diagnostics) {
            startActivity(new Intent(this, DiagnosticsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void openPicker(boolean mediaOnly) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        if (mediaOnly) {
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        } else {
            intent.setType("*/*");
        }
        picker.launch(Intent.createChooser(intent, mediaOnly ? getString(R.string.add_media) : getString(R.string.add_files)));
    }

    private void collectUris(Intent data, boolean replace) {
        if (replace) pendingUris.clear();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) addUri(clip.getItemAt(i).getUri(), data.getFlags());
        } else {
            addUri(data.getData(), data.getFlags());
        }
        pushSelectionToServer();
    }

    private void addUri(Uri uri, int flags) {
        if (uri == null || pendingUris.contains(uri)) return;
        pendingUris.add(uri);
        try {
            int takeFlags = flags & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, takeFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Some providers/share intents do not offer persistable grants; the live grant is still usable.
        }
    }

    private void handleIncomingShare(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_SEND.equals(action)) {
            Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri != null) {
                pendingUris.clear();
                addUri(uri, intent.getFlags());
                pushSelectionToServer();
            }
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> uris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (uris != null) {
                pendingUris.clear();
                for (Uri uri : uris) addUri(uri, intent.getFlags());
                pushSelectionToServer();
            }
        }
    }

    private void pushSelectionToServer() {
        if (server != null) server.setUris(pendingUris);
        updateSelectionStatus();
        if (!pendingUris.isEmpty()) {
            Toast.makeText(this, R.string.open_link_on_mac, Toast.LENGTH_SHORT).show();
        }
    }

    private void updateSelectionStatus() {
        if (selectionStatus == null) return;
        if (pendingUris.isEmpty()) {
            selectionStatus.setText(R.string.no_files_selected);
        } else {
            selectionStatus.setText(getResources().getQuantityString(
                    R.plurals.files_selected, pendingUris.size(), pendingUris.size()));
        }
    }

    private void startLocalReceiver() {
        List<String> addresses = LocalTransferServer.localIpv4Addresses();
        if (addresses.isEmpty()) {
            receiverUrl = null;
            serverAddress.setText(R.string.no_local_network);
            networkHint.setText(R.string.connect_same_wifi);
            copyLink.setEnabled(false);
            Diagnostics.log("WEB", "No private IPv4 address available");
            return;
        }

        int port = LocalTransferServer.DEFAULT_PORT;
        LocalTransferServer candidate = null;
        for (int p = port; p < port + 10; p++) {
            try {
                candidate = new LocalTransferServer(this, p);
                candidate.setListener(this);
                candidate.start(5000, false);
                port = p;
                break;
            } catch (Exception e) {
                Diagnostics.log("WEB", "Port " + p + " unavailable: " + e);
                if (candidate != null) candidate.stop();
                candidate = null;
            }
        }

        if (candidate == null) {
            receiverUrl = null;
            serverAddress.setText(R.string.receiver_start_failed);
            copyLink.setEnabled(false);
            return;
        }

        server = candidate;
        server.setUris(pendingUris);
        receiverUrl = "http://" + addresses.get(0) + ":" + port;
        StringBuilder displayedUrls = new StringBuilder();
        for (String address : addresses) {
            if (displayedUrls.length() > 0) displayedUrls.append("\n");
            displayedUrls.append("http://").append(address).append(":").append(port);
        }
        serverAddress.setText(displayedUrls.toString());
        networkHint.setText(R.string.receiver_instructions);
        copyLink.setEnabled(true);
        Diagnostics.log("WEB", "Local receiver ready at " + receiverUrl + "; addresses=" + addresses);
        refreshConnectionState(false);
    }

    private void copyReceiverLink() {
        if (receiverUrl == null) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Sendly receiver", receiverUrl));
        Toast.makeText(this, R.string.link_copied, Toast.LENGTH_SHORT).show();
    }

    private void refreshConnectionState(boolean toastIfMissing) {
        String client = server == null ? null : server.getLastClientLabel();
        if (client == null) {
            connectionStatus.setText(R.string.waiting_for_mac);
            if (toastIfMissing) Toast.makeText(this, R.string.open_receiver_first, Toast.LENGTH_SHORT).show();
        } else {
            connectionStatus.setText(client);
        }
    }

    @Override
    public void onClientSeen(String label) {
        runOnUiThread(() -> connectionStatus.setText(label));
    }

    @Override
    public void onFileRequested(String name) {
        runOnUiThread(() -> connectionStatus.setText(getString(R.string.downloading_on_mac, name)));
    }
}
