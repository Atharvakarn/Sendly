# Build Sendly with GitHub Actions

Sendly can be compiled entirely in GitHub's cloud build environment. No Android IDE, Mac, PC, or local Android SDK is required.

## Files to upload

1. `Sendly-v0.4.0-beta1-source.zip`
2. The supplied workflow, saved in the repository as `.github/workflows/build-sendly.yml`

## GitHub steps

1. Upload `Sendly-v0.4.0-beta1-source.zip` to the repository root.
2. Edit `.github/workflows/build-sendly.yml` and replace it with the v0.4 workflow.
3. Commit both changes to `main`.
4. Open **Actions** > **Build Sendly APK**.
5. Wait for the build to complete.
6. Download the `Sendly-v0.4.0-beta1` artifact.
7. Extract it and install `Sendly-v0.4.0-beta1.apk` on Android.

The test APK is debug-signed and directly installable. For long-term updates, use a persistent release signing key.

## Test checklist

1. Put the Mac and Android phone on the same Wi-Fi, or connect the Mac to the phone hotspot.
2. Open Sendly on Android.
3. Open the displayed local address on the Mac.
4. Android → Mac: select a small file on Android and download it from the browser.
5. Mac → Android: drag a small file onto the Sendly browser page. Confirm it appears in `Downloads/Sendly`.
6. Android → Mac text: copy text on Android, tap **Use phone clipboard**, then **Copy on Mac** in the browser.
7. Mac → Android text: paste/type text in the Mac browser and tap **Send to phone clipboard**.
8. If something fails, open **Diagnostics** in Sendly and share the log.
