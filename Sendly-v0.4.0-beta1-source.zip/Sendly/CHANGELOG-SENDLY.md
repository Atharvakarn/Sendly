# Sendly changelog

## 0.4.0-beta1

- Added Mac → Android file transfer using drag-and-drop or Choose Files in the browser.
- Incoming Mac files save to `Downloads/Sendly` on Android 10+.
- Added two-way text clipboard bridge with browser-safe one-click copy/paste flow.
- Added Share → Sendly support for text from Android apps.
- Added QR code for the local Sendly browser address.
- Added live browser polling so phone files and shared text update without refreshing.
- Added paste handling on the Mac page for text and copied files/screenshots.
- Rebuilt the Android home screen using Material 3 cards, typography and controls.
- Rebuilt the browser receiver with a current responsive UI.
- Kept all transfer traffic local to the LAN or phone hotspot.

## 0.3.0-beta1

- Replaced experimental native AirDrop discovery with reliable browser receiver mode.
- No Mac app installation required.
- Direct local HTTP transfer over the same Wi-Fi network or phone hotspot.
- Added Photos & videos and Files selection flow.
- Added Android share-sheet support directly into Sendly.
- Added local receiver link with Copy Link action.
- Nearby Devices now reports when a Mac browser connects.
- Added browser-side Sendly download page using brand accent #E90130.
- Kept persistent diagnostics for testing.
- Files remain local and are not uploaded to a cloud service.
