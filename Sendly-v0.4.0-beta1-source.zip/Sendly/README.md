# Sendly

Sendly moves files and text between Android and macOS without installing anything on the Mac.

## v0.4 browser bridge

1. Open Sendly on Android.
2. Open the local Sendly address in Safari, Chrome, Edge or Firefox on the Mac.
3. Transfer in either direction:
   - Android → Mac: choose files on Android, then download them in the Mac browser.
   - Mac → Android: drag files into the browser or choose files. They are saved to `Downloads/Sendly` on Android.
   - Android → Mac text: use the Clipboard card or Share → Sendly, then copy it on the Mac page.
   - Mac → Android text: paste/type in the Mac page and send it to the phone clipboard.
4. A QR code is shown on Android as an optional shortcut to the local browser address.

The devices must be on the same local network. If the router isolates clients, connect the Mac to the phone hotspot instead.

No cloud upload, account, or macOS companion application is required.

### Why browser mode?

Modern AirDrop uses Apple's AWDL peer-to-peer Wi-Fi layer. Ordinary Android applications cannot reliably access or emulate that interface on typical unrooted Android hardware. Sendly uses standard local HTTP instead, which is stable across Android and macOS versions.

### Clipboard limitation

A web browser cannot monitor the whole macOS clipboard in the background. Sendly therefore uses explicit browser actions: paste text on the Mac page to send it to Android, and click Copy on the Mac page for text shared by Android. Automatic Universal Clipboard-style background sync would require a Mac helper application.

## Build

```bash
./gradlew assembleDebug
```

Debug APK:

`app/build/outputs/apk/debug/app-debug.apk`

Sendly is an independent project and is not affiliated with Apple Inc.
