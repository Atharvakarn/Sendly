package com.sendly.transfer;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Small persistent diagnostic log so testing does not require adb or a computer. */
public final class Diagnostics {
    private static final String TAG = "SendlyDiag";
    private static final Object LOCK = new Object();
    private static final long MAX_BYTES = 256 * 1024;
    private static File logFile;

    private Diagnostics() {}

    public static void init(Context context) {
        synchronized (LOCK) {
            logFile = new File(context.getFilesDir(), "sendly-diagnostics.txt");
        }
        log("APP", "Sendly started; Android " + Build.VERSION.RELEASE
                + " (SDK " + Build.VERSION.SDK_INT + "), " + Build.MANUFACTURER + " " + Build.MODEL);
    }

    public static void log(String area, String message) {
        Log.d(TAG, area + ": " + message);
        synchronized (LOCK) {
            if (logFile == null) return;
            if (logFile.length() > MAX_BYTES) {
                // Keep testing simple: rotate a single small file.
                //noinspection ResultOfMethodCallIgnored
                logFile.delete();
            }
            String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
            String line = ts + "  " + area + "  " + message + "\n";
            try (FileOutputStream out = new FileOutputStream(logFile, true)) {
                out.write(line.getBytes(StandardCharsets.UTF_8));
            } catch (IOException e) {
                Log.w(TAG, "Unable to write diagnostics", e);
            }
        }
    }

    public static String read() {
        synchronized (LOCK) {
            if (logFile == null || !logFile.exists()) return "No diagnostics yet.";
            try {
                return new String(java.nio.file.Files.readAllBytes(logFile.toPath()), StandardCharsets.UTF_8);
            } catch (IOException e) {
                return "Could not read diagnostics: " + e;
            }
        }
    }

    public static void clear() {
        synchronized (LOCK) {
            if (logFile != null && logFile.exists()) {
                //noinspection ResultOfMethodCallIgnored
                logFile.delete();
            }
        }
        log("APP", "Diagnostics cleared");
    }
}
