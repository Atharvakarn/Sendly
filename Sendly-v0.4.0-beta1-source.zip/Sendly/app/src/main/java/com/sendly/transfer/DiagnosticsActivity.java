package com.sendly.transfer;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DiagnosticsActivity extends AppCompatActivity {
    private TextView logView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diagnostics);
        setTitle(R.string.diagnostics_title);

        logView = findViewById(R.id.diagnostics_log);
        refresh();

        Button copy = findViewById(R.id.diagnostics_copy);
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Sendly diagnostics", Diagnostics.read()));
            Toast.makeText(this, "Diagnostics copied", Toast.LENGTH_SHORT).show();
        });

        Button share = findViewById(R.id.diagnostics_share);
        share.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Sendly diagnostics");
            intent.putExtra(Intent.EXTRA_TEXT, Diagnostics.read());
            startActivity(Intent.createChooser(intent, "Share diagnostics"));
        });

        Button clear = findViewById(R.id.diagnostics_clear);
        clear.setOnClickListener(v -> {
            Diagnostics.clear();
            refresh();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        if (logView != null) logView.setText(Diagnostics.read());
    }
}
