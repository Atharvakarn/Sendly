/*
 * Copyright (C) 2019 The MoKee Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.sendly.transfer;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.io.InputStream;

public class GossipyInputStream extends InputStream {

    private final InputStream mSource;
    private final Listener mListener;

    public GossipyInputStream(InputStream source, Listener listener) {
        mSource = source;
        mListener = listener;
    }

    @Override
    public int read() throws IOException {
        final byte[] buf = new byte[1];
        final int ret = read(buf);
        return ret == -1 ? -1 : buf[0];
    }

    @Override
    public int read(@NonNull byte[] b, int off, int len) throws IOException {
        final int ret = mSource.read(b, off, len);
        if (ret == -1) {
            return -1;
        } else {
            mListener.onRead(ret);
            return ret;
        }
    }

    @Override
    public void close() throws IOException {
        super.close();
        mSource.close();
    }

    public interface Listener {

        void onRead(int length);

    }

}
