package com.sendly.transfer;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.util.ArrayList;
import java.util.List;

/** Main Sendly UI for browser-based local transfer. */
public class MainActivity extends AppCompatActivity implements LocalTransferServer.Listener {

    private final List<Uri> pendingUris = new ArrayList<>();

    private TextView selectionStatus;
    private TextView serverAddress;
    private TextView connectionStatus;
    private TextView networkHint;
    private TextView incomingStatus;
    private TextInputEditText clipboardText;
    private ImageView qrCode;
    private MaterialButton copyLink;
    private MaterialButton shareLink;

    private LocalTransferServer server;
    private String receiverUrl;
    private boolean suppressTextWatcher;

    private final ActivityResultLauncher<Intent> picker = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    collectUris(result.getData(), true);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        selectionStatus = findViewById(R.id.selection_status);
        serverAddress = findViewById(R.id.server_address);
        connectionStatus = findViewById(R.id.connection_status);
        networkHint = findViewById(R.id.network_hint);
        incomingStatus = findViewById(R.id.incoming_status);
        clipboardText = findViewById(R.id.clipboard_text);
        qrCode = findViewById(R.id.qr_code);
        copyLink = findViewById(R.id.copy_link);
        shareLink = findViewById(R.id.share_link);

        findViewById(R.id.add_media).setOnClickListener(v -> openPicker(true));
        findViewById(R.id.add_files).setOnClickListener(v -> openPicker(false));
        findViewById(R.id.clear_selection).setOnClickListener(v -> clearSelection());
        findViewById(R.id.use_clipboard).setOnClickListener(v -> usePhoneClipboard());
        findViewById(R.id.clear_clipboard).setOnClickListener(v -> setSharedText(""));
        findViewById(R.id.refresh_connection).setOnClickListener(v -> refreshConnectionState(true));
        copyLink.setOnClickListener(v -> copyReceiverLink());
        shareLink.setOnClickListener(v -> shareReceiverLink());

        clipboardText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!suppressTextWatcher && server != null) server.setSharedText(s == null ? "" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        startLocalReceiver();
        handleIncomingShare(getIntent());
        updateSelectionStatus();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingShare(intent);
    }

    @Override
    protected void onDestroy() {
        if (server != null) {
            server.setListener(null);
            server.stop();
            Diagnostics.log("WEB", "Local receiver stopped");
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.diagnostics) {
            startActivity(new Intent(this, DiagnosticsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void openPicker(boolean mediaOnly) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        if (mediaOnly) {
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        } else {
            intent.setType("*/*");
        }
        picker.launch(Intent.createChooser(intent,
                mediaOnly ? getString(R.string.add_media) : getString(R.string.add_files)));
    }

    private void collectUris(Intent data, boolean replace) {
        if (replace) pendingUris.clear();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                addUri(clip.getItemAt(i).getUri(), data.getFlags());
            }
        } else {
            addUri(data.getData(), data.getFlags());
        }
        pushSelectionToServer();
    }

    private void addUri(Uri uri, int flags) {
        if (uri == null || pendingUris.contains(uri)) return;
        pendingUris.add(uri);
        try {
            int takeFlags = flags & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, takeFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Share intents and some providers only grant access for the current app session.
        }
    }

    @SuppressWarnings("deprecation")
    private void handleIncomingShare(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_SEND.equals(action)) {
            Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);

            if (uri != null) {
                pendingUris.clear();
                addUri(uri, intent.getFlags());
                pushSelectionToServer();
            }
            if (text != null && text.length() > 0) {
                setSharedText(text.toString());
                Toast.makeText(this, R.string.text_ready_for_mac, Toast.LENGTH_SHORT).show();
            }
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> uris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (uris != null) {
                pendingUris.clear();
                for (Uri uri : uris) addUri(uri, intent.getFlags());
                pushSelectionToServer();
            }
        }
    }

    private void pushSelectionToServer() {
        if (server != null) server.setUris(pendingUris);
        updateSelectionStatus();
        if (!pendingUris.isEmpty()) {
            Toast.makeText(this, R.string.open_link_on_mac, Toast.LENGTH_SHORT).show();
        }
    }

    private void clearSelection() {
        pendingUris.clear();
        pushSelectionToServer();
    }

    private void updateSelectionStatus() {
        if (pendingUris.isEmpty()) {
            selectionStatus.setText(R.string.no_files_selected_modern);
        } else {
            selectionStatus.setText(getResources().getQuantityString(
                    R.plurals.files_selected_ready, pendingUris.size(), pendingUris.size()));
        }
    }

    private void startLocalReceiver() {
        List<String> addresses = LocalTransferServer.localIpv4Addresses();
        if (addresses.isEmpty()) {
            receiverUrl = null;
            serverAddress.setText(R.string.no_local_network);
            networkHint.setText(R.string.connect_same_wifi);
            copyLink.setEnabled(false);
            shareLink.setEnabled(false);
            qrCode.setVisibility(View.GONE);
            Diagnostics.log("WEB", "No private IPv4 address available");
            return;
        }

        int port = LocalTransferServer.DEFAULT_PORT;
        LocalTransferServer candidate = null;
        for (int p = port; p < port + 10; p++) {
            try {
                candidate = new LocalTransferServer(this, p);
                candidate.setListener(this);
                candidate.start(5000, false);
                port = p;
                break;
            } catch (Exception e) {
                Diagnostics.log("WEB", "Port " + p + " unavailable: " + e);
                if (candidate != null) candidate.stop();
                candidate = null;
            }
        }

        if (candidate == null) {
            receiverUrl = null;
            serverAddress.setText(R.string.receiver_start_failed);
            copyLink.setEnabled(false);
            shareLink.setEnabled(false);
            qrCode.setVisibility(View.GONE);
            return;
        }

        server = candidate;
        server.setUris(pendingUris);
        CharSequence existingText = clipboardText.getText();
        server.setSharedText(existingText == null ? "" : existingText.toString());

        receiverUrl = "http://" + addresses.get(0) + ":" + port;
        serverAddress.setText(receiverUrl);
        networkHint.setText(R.string.receiver_instructions_v04);
        copyLink.setEnabled(true);
        shareLink.setEnabled(true);
        showQr(receiverUrl);
        Diagnostics.log("WEB", "Local receiver ready at " + receiverUrl + "; addresses=" + addresses);
        refreshConnectionState(false);
    }

    private void showQr(String value) {
        try {
            Bitmap bitmap = createQrCode(value, 720);
            qrCode.setImageBitmap(bitmap);
            qrCode.setVisibility(View.VISIBLE);
        } catch (WriterException e) {
            qrCode.setVisibility(View.GONE);
            Diagnostics.log("QR", "QR generation failed: " + e);
        }
    }

    private static Bitmap createQrCode(String value, int size) throws WriterException {
        BitMatrix matrix = new QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, size, size);
        int[] pixels = new int[size * size];
        for (int y = 0; y < size; y++) {
            int offset = y * size;
            for (int x = 0; x < size; x++) {
                pixels[offset + x] = matrix.get(x, y) ? Color.BLACK : Color.WHITE;
            }
        }
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, size, 0, 0, size, size);
        return bitmap;
    }

    private void copyReceiverLink() {
        if (receiverUrl == null) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Sendly", receiverUrl));
        Toast.makeText(this, R.string.link_copied, Toast.LENGTH_SHORT).show();
    }

    private void shareReceiverLink() {
        if (receiverUrl == null) return;
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, receiverUrl);
        startActivity(Intent.createChooser(share, getString(R.string.share_connection_link)));
    }

    private void usePhoneClipboard() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (!clipboard.hasPrimaryClip() || clipboard.getPrimaryClip() == null
                || clipboard.getPrimaryClip().getItemCount() == 0) {
            Toast.makeText(this, R.string.clipboard_empty, Toast.LENGTH_SHORT).show();
            return;
        }

        CharSequence text = clipboard.getPrimaryClip().getItemAt(0).coerceToText(this);
        if (text == null || text.length() == 0) {
            Toast.makeText(this, R.string.clipboard_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        setSharedText(text.toString());
        Toast.makeText(this, R.string.text_ready_for_mac, Toast.LENGTH_SHORT).show();
    }

    private void setSharedText(String text) {
        suppressTextWatcher = true;
        clipboardText.setText(text);
        clipboardText.setSelection(clipboardText.length());
        suppressTextWatcher = false;
        if (server != null) server.setSharedText(text);
    }

    private void refreshConnectionState(boolean toastIfMissing) {
        String client = server == null ? null : server.getLastClientLabel();
        if (client == null) {
            connectionStatus.setText(R.string.waiting_for_mac_v04);
            if (toastIfMissing) {
                Toast.makeText(this, R.string.open_receiver_first, Toast.LENGTH_SHORT).show();
            }
        } else {
            connectionStatus.setText(client);
        }
    }

    @Override
    public void onClientSeen(String label) {
        runOnUiThread(() -> connectionStatus.setText(label));
    }

    @Override
    public void onFileRequested(String name) {
        runOnUiThread(() -> connectionStatus.setText(getString(R.string.downloading_on_mac, name)));
    }

    @Override
    public void onUploadReceived(String name, long bytes) {
        runOnUiThread(() -> {
            incomingStatus.setText(getString(R.string.received_from_mac, name));
            Toast.makeText(this, getString(R.string.received_to_downloads, name), Toast.LENGTH_LONG).show();
        });
    }

    @Override
    public void onTextReceived(String text) {
        runOnUiThread(() -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Sendly", text));
            setSharedText(text);
            incomingStatus.setText(R.string.text_received_from_mac);
            Toast.makeText(this, R.string.copied_to_phone_clipboard, Toast.LENGTH_SHORT).show();
        });
    }
}
