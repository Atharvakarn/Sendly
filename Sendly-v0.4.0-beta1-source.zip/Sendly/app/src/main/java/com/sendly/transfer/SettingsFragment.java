package com.sendly.transfer;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.preference.EditTextPreference;
import androidx.preference.PreferenceFragmentCompat;

public class SettingsFragment extends PreferenceFragmentCompat implements
        SharedPreferences.OnSharedPreferenceChangeListener {
    private ConfigManager mConfigManager;

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        addPreferencesFromResource(R.xml.settings);
        getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
        mConfigManager = new ConfigManager(getContext());
        EditTextPreference namePref = findPreference(ConfigManager.KEY_NAME);
        if (namePref != null) {
            namePref.setText(mConfigManager.getNameWithoutDefault());
            namePref.setSummary(mConfigManager.getName());
            namePref.setOnBindEditTextListener(editText -> editText.setHint(mConfigManager.getDefaultName()));
        }
    }

    @Override
    public void onDestroy() {
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        super.onDestroy();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        if (ConfigManager.KEY_NAME.equals(key)) {
            EditTextPreference namePref = findPreference(ConfigManager.KEY_NAME);
            if (namePref != null) namePref.setSummary(mConfigManager.getName());
        }
    }
}
