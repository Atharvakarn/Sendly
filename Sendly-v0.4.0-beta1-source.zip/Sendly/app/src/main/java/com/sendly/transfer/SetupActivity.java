package com.sendly.transfer;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.sendly.transfer.airdrop.AirDropManager;

import static android.bluetooth.BluetoothAdapter.ACTION_REQUEST_ENABLE;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;
import static android.provider.Settings.ACTION_WIFI_SETTINGS;
import static com.sendly.transfer.airdrop.AirDropManager.STATUS_NO_BLUETOOTH;
import static com.sendly.transfer.airdrop.AirDropManager.STATUS_NO_WIFI;

public class SetupActivity extends AppCompatActivity {
    private static final int REQUEST_PERM = 1;

    private AirDropManager mAirDropManager;
    private ViewGroup mGroupPerm;
    private ViewGroup mGroupWifi;
    private ViewGroup mGroupBt;

    private final WifiStateMonitor mWifiStateMonitor = new WifiStateMonitor() {
        @Override public void onReceive(Context context, Intent intent) { updateState(); }
    };
    private final BluetoothStateMonitor mBluetoothStateMonitor = new BluetoothStateMonitor() {
        @Override public void onReceive(Context context, Intent intent) { updateState(); }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);
        mGroupPerm = findViewById(R.id.group_perm);
        findViewById(R.id.perm).setOnClickListener(v -> requestPermission());
        mGroupWifi = findViewById(R.id.group_wifi);
        findViewById(R.id.wifi).setOnClickListener(v -> startActivity(new Intent(ACTION_WIFI_SETTINGS)));
        mGroupBt = findViewById(R.id.group_bt);
        findViewById(R.id.bt).setOnClickListener(v -> turnOnBluetooth());
        mAirDropManager = new AirDropManager(this, SendlyApplication.from(this).getCertificateManager());
        mWifiStateMonitor.register(this);
        mBluetoothStateMonitor.register(this);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        mWifiStateMonitor.unregister(this);
        mBluetoothStateMonitor.unregister(this);
        mAirDropManager.destroy();
    }

    @Override protected void onResume() { super.onResume(); updateState(); }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        return checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PERMISSION_GRANTED;
    }

    private void updateState() {
        if (!hasPermissions()) {
            mGroupPerm.setVisibility(View.VISIBLE);
            mGroupWifi.setVisibility(View.GONE);
            mGroupBt.setVisibility(View.GONE);
            return;
        }
        final int ready = mAirDropManager.ready();
        if (ready == STATUS_NO_WIFI) {
            mGroupPerm.setVisibility(View.GONE);
            mGroupWifi.setVisibility(View.VISIBLE);
            mGroupBt.setVisibility(View.GONE);
        } else if (ready == STATUS_NO_BLUETOOTH) {
            mGroupPerm.setVisibility(View.GONE);
            mGroupWifi.setVisibility(View.GONE);
            mGroupBt.setVisibility(View.VISIBLE);
        } else {
            setResult(RESULT_OK);
            finish();
        }
    }

    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_ADVERTISE,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, REQUEST_PERM);
        } else {
            updateState();
        }
    }

    @SuppressLint("MissingPermission")
    private void turnOnBluetooth() { startActivity(new Intent(ACTION_REQUEST_ENABLE)); }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_PERM) return;
        boolean granted = grantResults.length > 0;
        for (int result : grantResults) granted &= result == PERMISSION_GRANTED;
        if (!granted) {
            new AlertDialog.Builder(this)
                    .setTitle("Grant permissions")
                    .setMessage("Sendly needs Nearby devices permission to advertise the AirDrop discovery signal over Bluetooth.")
                    .setPositiveButton("Open settings", (dialog, which) -> {
                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                .setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        } else {
            updateState();
        }
    }
}
