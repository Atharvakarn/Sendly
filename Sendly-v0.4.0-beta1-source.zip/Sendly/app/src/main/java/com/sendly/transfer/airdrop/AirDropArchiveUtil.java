package com.sendly.transfer.airdrop;

import org.apache.commons.compress.archivers.cpio.CpioArchiveEntry;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.apache.commons.compress.utils.CharsetNames;
import com.sendly.transfer.GossipyInputStream;
import com.sendly.transfer.base.Entity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.zip.DeflaterOutputStream;

import okio.BufferedSource;
import okio.ByteString;
import okio.Okio;

import static org.apache.commons.compress.archivers.cpio.CpioConstants.C_IRGRP;
import static org.apache.commons.compress.archivers.cpio.CpioConstants.C_IROTH;
import static org.apache.commons.compress.archivers.cpio.CpioConstants.C_IRUSR;
import static org.apache.commons.compress.archivers.cpio.CpioConstants.C_ISREG;
import static org.apache.commons.compress.archivers.cpio.CpioConstants.C_IWUSR;
import static org.apache.commons.compress.archivers.cpio.CpioConstants.FORMAT_OLD_ASCII;

class AirDropArchiveUtil {
    private static final int DVZIP_BLOCK = 128 * 1024;

    /** Original Sendly payload: gzip-compressed ODC CPIO. */
    static void packLegacy(List<Entity> entities, OutputStream output,
                           GossipyInputStream.Listener listener) throws IOException {
        try (GzipCompressorOutputStream gzip = new GzipCompressorOutputStream(output)) {
            packCpio(entities, gzip, listener);
        }
    }

    /**
     * Modern Apple payload: ODC CPIO wrapped in dvzip blocks.
     * Each block has a big-endian 32-bit length. Bit 31 means the block is stored;
     * otherwise the payload is a zlib stream. Apple uses 128 KiB decompressed blocks.
     */
    static void packDvzip(List<Entity> entities, OutputStream output,
                          GossipyInputStream.Listener listener) throws IOException {
        try (DvzipOutputStream dvzip = new DvzipOutputStream(output)) {
            packCpio(entities, dvzip, listener);
        }
    }

    private static void packCpio(List<Entity> entities, OutputStream output,
                                 GossipyInputStream.Listener listener) throws IOException {
        try (CpioArchiveOutputStream cpio = new CpioArchiveOutputStream(
                output, FORMAT_OLD_ASCII, 512, CharsetNames.UTF_8)) {
            for (Entity entity : entities) {
                CpioArchiveEntry entry = new CpioArchiveEntry(FORMAT_OLD_ASCII, entity.path());
                entry.setMode(C_ISREG | C_IRUSR | C_IWUSR | C_IRGRP | C_IROTH);
                entry.setTime(TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));

                InputStream stream = new GossipyInputStream(entity.stream(), listener);
                BufferedSource source = Okio.buffer(Okio.source(stream));
                long size = entity.size();
                if (size == -1) {
                    ByteString content = source.readByteString();
                    entry.setSize(content.size());
                    cpio.putArchiveEntry(entry);
                    content.write(cpio);
                } else {
                    entry.setSize(size);
                    cpio.putArchiveEntry(entry);
                    source.readAll(Okio.sink(cpio));
                }
                cpio.closeArchiveEntry();
                source.close();
            }
        }
    }

    private static final class DvzipOutputStream extends OutputStream {
        private final OutputStream out;
        private final byte[] block = new byte[DVZIP_BLOCK];
        private int count = 0;
        private boolean closed = false;

        DvzipOutputStream(OutputStream out) { this.out = out; }

        @Override public void write(int b) throws IOException {
            block[count++] = (byte) b;
            if (count == block.length) flushBlock();
        }

        @Override public void write(byte[] b, int off, int len) throws IOException {
            while (len > 0) {
                int n = Math.min(len, block.length - count);
                System.arraycopy(b, off, block, count, n);
                count += n;
                off += n;
                len -= n;
                if (count == block.length) flushBlock();
            }
        }

        private void flushBlock() throws IOException {
            if (count == 0) return;
            ByteArrayOutputStream compressedBuffer = new ByteArrayOutputStream(count);
            try (DeflaterOutputStream deflater = new DeflaterOutputStream(compressedBuffer)) {
                deflater.write(block, 0, count);
            }
            byte[] compressed = compressedBuffer.toByteArray();
            if (compressed.length < count) {
                writeHeader(compressed.length);
                out.write(compressed);
            } else {
                writeHeader(0x80000000 | count);
                out.write(block, 0, count);
            }
            count = 0;
        }

        private void writeHeader(int value) throws IOException {
            out.write((value >>> 24) & 0xff);
            out.write((value >>> 16) & 0xff);
            out.write((value >>> 8) & 0xff);
            out.write(value & 0xff);
        }

        @Override public void flush() throws IOException { out.flush(); }

        @Override public void close() throws IOException {
            if (closed) return;
            closed = true;
            flushBlock();
            out.close();
        }
    }
}
