package com.sendly.transfer.airdrop;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.Context;
import android.util.Log;

import com.sendly.transfer.Diagnostics;

import static android.content.Context.BLUETOOTH_SERVICE;

/** BLE wake advertisement used to make nearby Macs expose their AirDrop service. */
class AirDropBleController {
    private static final String TAG = "AirDropBleController";
    private static final int MANUFACTURER_ID = 0x004C;
    private static final byte[] MANUFACTURER_DATA = {
            0x05, 0x12, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00};

    private final Object mLock = new Object();
    private final Context mContext;
    private BluetoothLeAdvertiser mAdvertiser;

    private final AdvertiseCallback mAdvertiseCallback = new AdvertiseCallback() {
        @Override public void onStartSuccess(AdvertiseSettings settingsInEffect) {
            Diagnostics.log("BLE", "AirDrop wake advertisement started");
        }
        @Override public void onStartFailure(int errorCode) {
            Log.e(TAG, "Start advertise failed: " + errorCode);
            Diagnostics.log("BLE", "AirDrop wake advertisement failed, code=" + errorCode);
        }
    };

    AirDropBleController(Context context) { mContext = context; }

    private void getAdvertiser() {
        BluetoothManager manager = (BluetoothManager) mContext.getSystemService(BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null || !adapter.isEnabled()) {
            mAdvertiser = null;
            return;
        }
        mAdvertiser = adapter.getBluetoothLeAdvertiser();
    }

    boolean ready() {
        synchronized (mLock) {
            try {
                getAdvertiser();
                boolean ok = mAdvertiser != null;
                Diagnostics.log("BLE", ok ? "Bluetooth LE advertiser ready" : "Bluetooth LE advertiser unavailable");
                return ok;
            } catch (SecurityException e) {
                Diagnostics.log("BLE", "Bluetooth permission missing: " + e);
                return false;
            }
        }
    }

    void triggerDiscoverable() {
        synchronized (mLock) {
            try {
                getAdvertiser();
                if (mAdvertiser == null) return;
                mAdvertiser.startAdvertising(
                        new AdvertiseSettings.Builder()
                                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                                .setConnectable(true)
                                .build(),
                        new AdvertiseData.Builder()
                                .addManufacturerData(MANUFACTURER_ID, MANUFACTURER_DATA)
                                .build(),
                        mAdvertiseCallback);
            } catch (SecurityException e) {
                Diagnostics.log("BLE", "Could not advertise: " + e);
            }
        }
    }

    void stop() {
        synchronized (mLock) {
            try {
                if (mAdvertiser != null) mAdvertiser.stopAdvertising(mAdvertiseCallback);
            } catch (SecurityException ignored) {}
        }
    }
}
