package com.sendly.transfer.airdrop;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;

import com.dd.plist.NSDictionary;
import com.dd.plist.PropertyListFormatException;
import com.dd.plist.PropertyListParser;

import com.sendly.transfer.Diagnostics;
import com.sendly.transfer.certificate.CertificateManager;
import org.xml.sax.SAXException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketAddress;
import java.text.ParseException;
import java.util.Collections;
import java.util.Map;

import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import javax.xml.parsers.ParserConfigurationException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;
import okio.BufferedSink;
import okio.Okio;

class AirDropClient {
    private static final String TAG = "AirDropClient";
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final OkHttpClient mHttpClient;
    private NetworkInterface mInterface;

    AirDropClient(CertificateManager certificateManager) {
        SSLSocketFactory sslSocketFactory = certificateManager.createClientSSLSocketFactory();
        X509TrustManager trustManager = certificateManager.getTrustManager();
        mHttpClient = new OkHttpClient.Builder()
                .socketFactory(new LinkLocalAddressSocketFactory())
                .sslSocketFactory(sslSocketFactory, trustManager)
                .hostnameVerifier((hostname, session) -> true)
                .retryOnConnectionFailure(true)
                .build();
    }

    void setNetworkInterface(NetworkInterface iface) { mInterface = iface; }

    Call post(final String url, NSDictionary body, AirDropClientCallback callback) {
        Buffer buffer = new Buffer();
        try {
            PropertyListParser.saveAsBinary(body, buffer.outputStream());
        } catch (IOException e) {
            callback.onFailure(e);
            return null;
        }
        RequestBody requestBody = RequestBody.create(buffer.readByteString(), MediaType.get("application/octet-stream"));
        buffer.close();
        return post(url, requestBody, Collections.emptyMap(), callback);
    }

    Call postUpload(final String url, final InputStream input, final String contentType,
                    Map<String, String> headers, AirDropClientCallback callback) {
        RequestBody body = new RequestBody() {
            @Override public MediaType contentType() { return MediaType.get(contentType); }
            @Override public void writeTo(@NonNull BufferedSink sink) throws IOException {
                try {
                    sink.writeAll(Okio.source(input));
                } finally {
                    input.close();
                }
            }
        };
        return post(url, body, headers, callback);
    }

    private Call post(final String url, RequestBody body, Map<String, String> headers,
                      final AirDropClientCallback callback) {
        Request.Builder builder = new Request.Builder()
                .url(url)
                .header("User-Agent", "AirDrop/1.0")
                .header("Connection", "keep-alive")
                .post(body);
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            if (entry.getValue() != null) builder.header(entry.getKey(), entry.getValue());
        }
        Request request = builder.build();
        Diagnostics.log("HTTP", "POST " + request.url().encodedPath() + " -> " + url);

        Call call = mHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                if (call.isCanceled()) {
                    Diagnostics.log("HTTP", request.url().encodedPath() + " canceled");
                    Log.w(TAG, "Request canceled", e);
                } else {
                    Diagnostics.log("HTTP", request.url().encodedPath() + " failed: " + e);
                    Log.e(TAG, "Request failed: " + url, e);
                    postFailure(callback, e);
                }
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                try (Response r = response) {
                    int statusCode = r.code();
                    Diagnostics.log("HTTP", request.url().encodedPath() + " response=" + statusCode);
                    if (statusCode != 200) {
                        postFailure(callback, new IOException("Request failed: HTTP " + statusCode));
                        return;
                    }
                    ResponseBody responseBody = r.body();
                    if (responseBody == null) {
                        postResponse(callback, new NSDictionary());
                        return;
                    }
                    byte[] bytes = responseBody.bytes();
                    if (bytes.length == 0) {
                        postResponse(callback, new NSDictionary());
                        return;
                    }
                    try {
                        NSDictionary root = (NSDictionary) PropertyListParser.parse(new ByteArrayInputStream(bytes));
                        postResponse(callback, root);
                    } catch (PropertyListFormatException | ParseException |
                             ParserConfigurationException | SAXException e) {
                        postFailure(callback, new IOException(e));
                    }
                } catch (IOException e) {
                    postFailure(callback, e);
                }
            }
        });
        return call;
    }

    private void postResponse(final AirDropClientCallback callback, final NSDictionary response) {
        mHandler.post(() -> callback.onResponse(response));
    }

    private void postFailure(final AirDropClientCallback callback, final IOException e) {
        mHandler.post(() -> callback.onFailure(e));
    }

    interface AirDropClientCallback {
        void onFailure(IOException e);
        void onResponse(NSDictionary response);
    }

    private class LinkLocalAddressSocketFactory extends SocketFactory {
        @Override
        public Socket createSocket() {
            return new Socket() {
                @Override
                public void connect(SocketAddress endpoint, int timeout) throws IOException {
                    if (mInterface != null && endpoint instanceof InetSocketAddress) {
                        InetSocketAddress socketAddress = (InetSocketAddress) endpoint;
                        if (socketAddress.getAddress() instanceof Inet6Address) {
                            Inet6Address address = (Inet6Address) socketAddress.getAddress();
                            InetAddress scoped = Inet6Address.getByAddress(null, address.getAddress(), mInterface);
                            endpoint = new InetSocketAddress(scoped, socketAddress.getPort());
                            Diagnostics.log("NET", "Scoped IPv6 connect via " + mInterface.getName()
                                    + " to " + scoped.getHostAddress() + ":" + socketAddress.getPort());
                        }
                    }
                    super.connect(endpoint, timeout);
                }
            };
        }

        @Override public Socket createSocket(String host, int port) throws IOException {
            Socket s = createSocket(); s.connect(new InetSocketAddress(host, port)); return s;
        }
        @Override public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException {
            Socket s = createSocket(); s.bind(new InetSocketAddress(localHost, localPort)); s.connect(new InetSocketAddress(host, port)); return s;
        }
        @Override public Socket createSocket(InetAddress host, int port) throws IOException {
            Socket s = createSocket(); s.connect(new InetSocketAddress(host, port)); return s;
        }
        @Override public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException {
            Socket s = createSocket(); s.bind(new InetSocketAddress(localAddress, localPort)); s.connect(new InetSocketAddress(address, port)); return s;
        }
    }
}
