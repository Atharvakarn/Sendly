package com.sendly.transfer.airdrop;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;

import com.dd.plist.NSDictionary;

import com.sendly.transfer.Diagnostics;
import com.sendly.transfer.GossipyInputStream;
import com.sendly.transfer.base.DiscoverListener;
import com.sendly.transfer.base.Discoverer;
import com.sendly.transfer.base.Entity;
import com.sendly.transfer.base.SendListener;
import com.sendly.transfer.base.Sender;
import com.sendly.transfer.base.SendingSession;
import com.sendly.transfer.certificate.CertificateManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

import okhttp3.Call;
import okio.Okio;

import static com.sendly.transfer.airdrop.AirDropTypes.getEntryType;

/** Send-only AirDrop compatibility manager for Sendly. */
public class AirDropManager implements Discoverer, Sender<AirDropPeer> {
    public static final int STATUS_OK = 0;
    public static final int STATUS_NO_BLUETOOTH = 1;
    public static final int STATUS_NO_WIFI = 2;

    private static final String TAG = "AirDropManager";

    private final Context mContext;
    private final AirDropConfigManager mConfigManager;
    private final AirDropBleController mBleController;
    private final AirDropNsdController mNsdController;
    private final AirDropWlanController mWlanController;
    private final AirDropClient mClient;
    private final Map<String, AirDropPeer> mPeers = new HashMap<>();
    private final ExecutorService mArchiveExecutor = Executors.newFixedThreadPool(2);
    private final Handler mMainThreadHandler = new Handler(Looper.getMainLooper());
    private final String mSenderPseudonym;
    private final String mSenderPushToken;

    private DiscoverListener mDiscoverListener;

    public AirDropManager(Context context, CertificateManager certificateManager) {
        mContext = context.getApplicationContext();
        mConfigManager = new AirDropConfigManager(context);
        mBleController = new AirDropBleController(context);
        mNsdController = new AirDropNsdController(context, mConfigManager, this);
        mWlanController = new AirDropWlanController();
        mClient = new AirDropClient(certificateManager);

        SecureRandom random = new SecureRandom();
        byte[] pseudBytes = new byte[16];
        byte[] pushBytes = new byte[32];
        random.nextBytes(pseudBytes);
        random.nextBytes(pushBytes);
        mSenderPseudonym = "pseud:" + Base64.encodeToString(
                pseudBytes, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
        StringBuilder push = new StringBuilder(64);
        for (byte b : pushBytes) push.append(String.format(Locale.US, "%02X", b & 0xff));
        mSenderPushToken = push.toString();
    }

    private long totalLength(List<Entity> entities) {
        long total = 0;
        for (Entity entity : entities) {
            if (entity.size() < 0) return -1;
            total += entity.size();
        }
        return total;
    }

    public int ready() {
        if (!mBleController.ready()) return STATUS_NO_BLUETOOTH;
        if (!mWlanController.ready()) return STATUS_NO_WIFI;
        mClient.setNetworkInterface(mWlanController.getInterface());
        return STATUS_OK;
    }

    @Override
    public void startDiscover(DiscoverListener discoverListener) {
        if (ready() != STATUS_OK) {
            Diagnostics.log("AIRDROP", "Discovery not started: device not ready");
            return;
        }
        mDiscoverListener = discoverListener;
        Diagnostics.log("AIRDROP", "Starting AirDrop discovery");
        mBleController.triggerDiscoverable();
        mNsdController.startDiscover(mWlanController.getLocalAddresses());
    }

    @Override
    public void stopDiscover() {
        mBleController.stop();
        mNsdController.stopDiscover();
    }

    public void destroy() {
        mBleController.stop();
        mNsdController.destroy();
        mArchiveExecutor.shutdownNow();
    }

    void onServiceResolved(String id, String url) {
        NSDictionary req = new NSDictionary();
        mClient.post(url + "/Discover", req, new AirDropClient.AirDropClientCallback() {
            @Override public void onFailure(IOException e) {
                Log.w(TAG, "Failed to discover: " + id, e);
                Diagnostics.log("AIRDROP", "/Discover failed for " + id + ": " + e);
            }

            @Override public void onResponse(NSDictionary response) {
                AirDropPeer peer = AirDropPeer.from(response, id, url);
                if (peer == null) {
                    Diagnostics.log("AIRDROP", "/Discover response missing receiver name for " + id);
                    return;
                }
                mPeers.put(id, peer);
                Diagnostics.log("AIRDROP", "Mac discovered: " + peer.name + " (" + id + ")");
                if (mDiscoverListener != null) mDiscoverListener.onPeerFound(peer);
            }
        });
    }

    void onServiceLost(String id) {
        AirDropPeer peer = mPeers.remove(id);
        if (peer != null && mDiscoverListener != null) {
            mDiscoverListener.onPeerDisappeared(peer);
        }
    }

    @Override
    public SendingSession send(AirDropPeer peer, List<Entity> entities, SendListener listener) {
        String transferId = UUID.randomUUID().toString().toUpperCase(Locale.US);
        Diagnostics.log("AIRDROP", "Starting transfer " + transferId + " to " + peer.name
                + ", files=" + entities.size());
        AtomicReference<Cancelable> ref = new AtomicReference<>();
        ask(ref, peer, transferId, entities, listener);
        return new SendingSession() {
            @Override public void cancel() {
                Cancelable cancelable = ref.getAndSet(null);
                if (cancelable != null) cancelable.cancel();
                Diagnostics.log("AIRDROP", "Transfer canceled: " + transferId);
            }
        };
    }

    private void ask(AtomicReference<Cancelable> ref, AirDropPeer peer, String transferId,
                     List<Entity> entities, SendListener listener) {
        NSDictionary req = new NSDictionary();
        req.put("SenderID", mConfigManager.getId());
        req.put("SenderComputerName", mConfigManager.getName());
        req.put("SenderModelName", Build.MODEL);
        req.put("BundleID", "com.apple.finder");
        req.put("ConvertMediaFormats", false);

        NSDictionary transfer = new NSDictionary();
        transfer.put("id", transferId);
        req.put("TransferID", transfer);
        NSDictionary transferType = new NSDictionary();
        transferType.put("files", new NSDictionary());
        req.put("TransferType", transferType);

        List<NSDictionary> files = new ArrayList<>();
        for (Entity entity : entities) {
            NSDictionary file = new NSDictionary();
            file.put("FileName", entity.name());
            file.put("FileType", getEntryType(entity));
            file.put("FileBomPath", entity.path());
            file.put("FileIsDirectory", false);
            file.put("ConvertMediaFormats", 0);
            files.add(file);
        }
        req.put("Files", files);

        Diagnostics.log("AIRDROP", "POST /Ask TransferID=" + transferId);
        Call call = mClient.post(peer.url + "/Ask", req, new AirDropClient.AirDropClientCallback() {
            @Override public void onFailure(IOException e) {
                Diagnostics.log("AIRDROP", "/Ask rejected/failed: " + e);
                ref.set(null);
                listener.onRejected();
            }
            @Override public void onResponse(NSDictionary response) {
                Diagnostics.log("AIRDROP", "/Ask accepted TransferID=" + transferId);
                listener.onAccepted();
                upload(ref, peer, transferId, entities, listener);
            }
        });
        if (call != null) ref.set(call::cancel);
    }

    private void upload(AtomicReference<Cancelable> ref, AirDropPeer peer, String transferId,
                        List<Entity> entities, SendListener listener) {
        long sourceBytes = totalLength(entities);
        GossipyInputStream.Listener progress = new GossipyInputStream.Listener() {
            private long bytesPacked = 0;
            @Override public void onRead(int length) {
                if (sourceBytes < 0) return;
                bytesPacked += length;
                long current = Math.min(bytesPacked, sourceBytes);
                mMainThreadHandler.post(() -> listener.onProgress(current, sourceBytes));
            }
        };

        boolean legacy = mConfigManager.useLegacyUpload();
        String contentType = legacy ? "application/x-cpio" : "application/x-dvzip";

        // Apple currently sends TotalBytes as the actual /Upload payload length, not the
        // sum of the source file lengths. Build to a cache file first so this header is exact
        // while still allowing OkHttp to transmit the body with chunked framing.
        mArchiveExecutor.execute(() -> {
            File archiveFile = null;
            try {
                archiveFile = File.createTempFile(
                        "sendly-", legacy ? ".cpio" : ".dvzip", mContext.getCacheDir());
                try (FileOutputStream output = new FileOutputStream(archiveFile)) {
                    if (legacy) {
                        AirDropArchiveUtil.packLegacy(entities, output, progress);
                    } else {
                        AirDropArchiveUtil.packDvzip(entities, output, progress);
                    }
                }

                long payloadBytes = archiveFile.length();
                Map<String, String> headers = new HashMap<>();
                headers.put("TotalBytes", Long.toString(payloadBytes));
                headers.put("SenderPseudonym", mSenderPseudonym);
                headers.put("SenderPushToken", mSenderPushToken);
                headers.put("TransferID", transferId);

                Diagnostics.log("AIRDROP", "POST /Upload type=" + contentType
                        + " TransferID=" + transferId + " payloadBytes=" + payloadBytes);

                File finalArchiveFile = archiveFile;
                Call call = mClient.postUpload(peer.url + "/Upload",
                        new FileInputStream(archiveFile), contentType, headers,
                        new AirDropClient.AirDropClientCallback() {
                            @Override public void onFailure(IOException e) {
                                Diagnostics.log("AIRDROP", "/Upload failed: " + e);
                                ref.set(null);
                                if (!finalArchiveFile.delete()) finalArchiveFile.deleteOnExit();
                                listener.onSendFailed();
                            }

                            @Override public void onResponse(NSDictionary response) {
                                Diagnostics.log("AIRDROP", "/Upload accepted. Transfer complete.");
                                ref.set(null);
                                if (!finalArchiveFile.delete()) finalArchiveFile.deleteOnExit();
                                listener.onSent();
                            }
                        });
                if (call != null) ref.set(call::cancel);
            } catch (IOException e) {
                Diagnostics.log("AIRDROP", "Archive creation failed: " + e);
                if (archiveFile != null && archiveFile.exists() && !archiveFile.delete()) {
                    archiveFile.deleteOnExit();
                }
                mMainThreadHandler.post(listener::onSendFailed);
            }
        });
    }

    private interface Cancelable { void cancel(); }
}
