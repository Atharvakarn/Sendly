package com.sendly.transfer.airdrop;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;

import com.sendly.transfer.Diagnostics;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceInfo;
import javax.jmdns.ServiceListener;

class AirDropNsdController {
    private static final String TAG = "AirDropNsdController";
    private static final String SERVICE_TYPE = "_airdrop._tcp.local.";

    private final WifiManager.MulticastLock mMulticastLock;
    private final AirDropManager mParent;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final HandlerThread mNetworkingThread;
    private final Handler mNetworkingHandler;
    private final List<JmDNS> mInstances = new ArrayList<>();

    private final ServiceListener mDiscoveryListener = new ServiceListener() {
        @Override
        public void serviceAdded(ServiceEvent event) {
            Diagnostics.log("MDNS", "Service announced: " + event.getName());
            try {
                event.getDNS().requestServiceInfo(event.getType(), event.getName(), true);
            } catch (RuntimeException e) {
                Diagnostics.log("MDNS", "Resolve request failed: " + e);
            }
        }
        @Override public void serviceRemoved(ServiceEvent event) { handleServiceLost(event.getInfo()); }
        @Override public void serviceResolved(ServiceEvent event) { handleServiceResolved(event.getInfo()); }
    };

    @SuppressWarnings("ConstantConditions")
    AirDropNsdController(Context context, AirDropConfigManager ignored, AirDropManager parent) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        mMulticastLock = wifiManager.createMulticastLock(TAG);
        mMulticastLock.setReferenceCounted(false);
        mParent = parent;
        mNetworkingThread = new HandlerThread("airdrop-mdns");
        mNetworkingThread.start();
        mNetworkingHandler = new Handler(mNetworkingThread.getLooper());
    }

    void destroy() {
        mNetworkingHandler.post(() -> {
            closeAll();
            if (mMulticastLock.isHeld()) mMulticastLock.release();
            mNetworkingHandler.removeCallbacksAndMessages(null);
            mNetworkingThread.quit();
        });
    }

    private void closeAll() {
        for (JmDNS dns : mInstances) {
            try { dns.close(); } catch (IOException ignored) {}
        }
        mInstances.clear();
    }

    void startDiscover(final List<InetAddress> addresses) {
        mNetworkingHandler.post(() -> {
            if (!mMulticastLock.isHeld()) mMulticastLock.acquire();
            closeAll();
            for (InetAddress address : addresses) {
                try {
                    JmDNS dns = JmDNS.create(address);
                    dns.addServiceListener(SERVICE_TYPE, mDiscoveryListener);
                    mInstances.add(dns);
                    Diagnostics.log("MDNS", "Searching on " + address.getHostAddress());
                } catch (IOException | RuntimeException e) {
                    Diagnostics.log("MDNS", "Could not bind " + address.getHostAddress() + ": " + e);
                    Log.w(TAG, "Failed creating JmDNS for " + address, e);
                }
            }
            if (mInstances.isEmpty()) Diagnostics.log("MDNS", "No mDNS listener could be started");
        });
    }

    void stopDiscover() {
        mNetworkingHandler.post(() -> {
            closeAll();
            if (mMulticastLock.isHeld()) mMulticastLock.release();
            Diagnostics.log("MDNS", "Discovery stopped");
        });
    }

    private void handleServiceLost(ServiceInfo info) {
        if (info == null) return;
        Diagnostics.log("MDNS", "AirDrop service disappeared: " + info.getName());
        mHandler.post(() -> mParent.onServiceLost(info.getName()));
    }

    private void handleServiceResolved(ServiceInfo info) {
        if (info == null) return;
        StringBuilder all = new StringBuilder();
        for (Inet6Address a : info.getInet6Addresses()) all.append(" v6=").append(a.getHostAddress());
        for (Inet4Address a : info.getInet4Addresses()) all.append(" v4=").append(a.getHostAddress());
        Diagnostics.log("MDNS", "Resolved " + info.getName() + " port=" + info.getPort() + all);

        InetAddress chosen = null;
        for (Inet6Address a : info.getInet6Addresses()) {
            if (a.isLinkLocalAddress()) { chosen = a; break; }
            if (chosen == null) chosen = a;
        }
        if (chosen == null && info.getInet4Addresses().length > 0) chosen = info.getInet4Addresses()[0];
        if (chosen == null) {
            Diagnostics.log("MDNS", "Resolved service had no usable address");
            return;
        }

        String host = chosen.getHostAddress();
        int zone = host.indexOf('%');
        if (zone >= 0) host = host.substring(0, zone);
        String url = chosen instanceof Inet6Address
                ? "https://[" + host + "]:" + info.getPort()
                : "https://" + host + ":" + info.getPort();
        Diagnostics.log("MDNS", "Using AirDrop endpoint " + url);
        String id = info.getName();
        mHandler.post(() -> mParent.onServiceResolved(id, url));
    }
}
