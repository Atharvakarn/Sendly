/*
 * Copyright (C) 2019 The MoKee Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 */
package com.sendly.transfer.airdrop;

import android.util.Log;

import com.dd.plist.NSDictionary;
import com.dd.plist.NSObject;

import com.sendly.transfer.base.Peer;

/** Minimal representation of a discovered Apple AirDrop receiver. */
public class AirDropPeer extends Peer {
    private static final String TAG = "AirDropPeer";
    final String url;

    private AirDropPeer(String id, String name, String url) {
        super(id, name);
        this.url = url;
    }

    static AirDropPeer from(NSDictionary dict, String id, String url) {
        NSObject nameNode = dict.get("ReceiverComputerName");
        if (nameNode == null) {
            Log.w(TAG, "ReceiverComputerName missing: " + id);
            return null;
        }
        return new AirDropPeer(id, nameNode.toJavaObject(String.class), url);
    }
}
