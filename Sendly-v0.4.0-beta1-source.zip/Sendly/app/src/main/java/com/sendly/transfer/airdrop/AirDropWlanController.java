package com.sendly.transfer.airdrop;

import android.util.Log;

import com.sendly.transfer.Diagnostics;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

/** Finds usable Wi-Fi addresses. Modern AirDrop is IPv6-first, but we keep IPv4 fallback. */
class AirDropWlanController {
    private static final String TAG = "AirDropWlanController";
    private static final String[] INTERFACES = new String[]{"wlan1", "wlan0"};
    private final Object mLock = new Object();

    private NetworkInterface mInterface;
    private List<InetAddress> mLocalAddresses = Collections.emptyList();

    private void refresh() {
        NetworkInterface selected = null;
        List<InetAddress> selectedAddresses = new ArrayList<>();

        for (String name : INTERFACES) {
            NetworkInterface iface;
            try {
                iface = NetworkInterface.getByName(name);
            } catch (SocketException e) {
                Log.w(TAG, "Failed getting interface " + name, e);
                continue;
            }
            if (iface == null) continue;

            List<InetAddress> v6Link = new ArrayList<>();
            List<InetAddress> v4 = new ArrayList<>();
            List<InetAddress> v6Other = new ArrayList<>();
            Enumeration<InetAddress> addresses = iface.getInetAddresses();
            while (addresses.hasMoreElements()) {
                InetAddress a = addresses.nextElement();
                if (a.isLoopbackAddress() || a.isAnyLocalAddress()) continue;
                if (a instanceof Inet6Address) {
                    if (a.isLinkLocalAddress()) v6Link.add(a); else v6Other.add(a);
                } else if (a instanceof Inet4Address) {
                    v4.add(a);
                }
            }

            selectedAddresses.addAll(v6Link);
            selectedAddresses.addAll(v4);
            selectedAddresses.addAll(v6Other);
            if (!selectedAddresses.isEmpty()) {
                selected = iface;
                break;
            }
        }

        mInterface = selected;
        mLocalAddresses = selectedAddresses;
        if (mInterface == null || mLocalAddresses.isEmpty()) {
            Diagnostics.log("WIFI", "No usable wlan interface/address found");
            return;
        }
        StringBuilder msg = new StringBuilder("Using ").append(mInterface.getName()).append(":");
        for (InetAddress a : mLocalAddresses) msg.append(' ').append(a.getHostAddress());
        Diagnostics.log("WIFI", msg.toString());
    }

    boolean ready() {
        synchronized (mLock) {
            refresh();
            return mInterface != null && !mLocalAddresses.isEmpty();
        }
    }

    NetworkInterface getInterface() {
        synchronized (mLock) {
            refresh();
            return mInterface;
        }
    }

    InetAddress getLocalAddress() {
        synchronized (mLock) {
            refresh();
            return mLocalAddresses.isEmpty() ? null : mLocalAddresses.get(0);
        }
    }

    List<InetAddress> getLocalAddresses() {
        synchronized (mLock) {
            refresh();
            return new ArrayList<>(mLocalAddresses);
        }
    }
}
