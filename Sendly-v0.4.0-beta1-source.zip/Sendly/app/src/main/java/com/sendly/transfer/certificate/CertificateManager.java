package com.sendly.transfer.certificate;

import android.content.Context;

import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * AirDrop uses an ephemeral self-signed HTTPS certificate on the peer.
 * Sendly is a sender only, so the old embedded server keystore is not needed.
 */
public class CertificateManager {
    public CertificateManager(Context context) {
        // Kept for API compatibility with the existing application wiring.
    }

    public SSLSocketFactory createClientSSLSocketFactory() {
        try {
            SSLContext context = SSLContext.getInstance("TLS");
            context.init(null, new TrustManager[]{new TrustAllCerts()}, new SecureRandom());
            return context.getSocketFactory();
        } catch (Exception e) {
            throw new IllegalStateException("Unable to create AirDrop TLS context", e);
        }
    }

    public X509TrustManager getTrustManager() {
        return new TrustAllCerts();
    }

    private static final class TrustAllCerts implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType)
                throws CertificateException {
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType)
                throws CertificateException {
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }
}
