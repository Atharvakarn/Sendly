#!/usr/bin/env bash
set -e
chmod +x ./gradlew
./gradlew --no-daemon assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
