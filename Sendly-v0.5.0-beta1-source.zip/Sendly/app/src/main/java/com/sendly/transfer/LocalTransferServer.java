package com.sendly.transfer;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;

import androidx.core.content.FileProvider;

import fi.iki.elonen.NanoHTTPD;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URLEncoder;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Local browser bridge for Sendly. The phone hosts a small HTTP server so a Mac can
 * download phone files, upload files to Android, and exchange text without a Mac app.
 */
public final class LocalTransferServer extends NanoHTTPD {

    public interface Listener {
        void onClientSeen(String label);
        void onFileRequested(String name);
        void onUploadReceived(ReceivedFile file);
        void onTextReceived(String text);
    }

    public static final int DEFAULT_PORT = 8765;
    private static final int MAX_TEXT_CHARS = 200_000;

    private final Context context;
    private final List<SharedItem> items = Collections.synchronizedList(new ArrayList<>());
    private volatile Listener listener;
    private volatile String lastClientLabel;
    private volatile String sharedText = "";
    private volatile String lastReceivedName = "";
    private volatile long lastClientLogAt;

    public LocalTransferServer(Context context, int port) {
        super(port);
        this.context = context.getApplicationContext();
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setUris(List<Uri> uris) {
        synchronized (items) {
            items.clear();
            for (Uri uri : uris) {
                if (uri != null) items.add(SharedItem.from(context, uri));
            }
        }
        Diagnostics.log("WEB", "Updated browser share with " + items.size() + " item(s)");
    }

    public void setSharedText(String text) {
        sharedText = text == null ? "" : text;
        Diagnostics.log("TEXT", "Shared text updated; chars=" + sharedText.length());
    }

    public String getSharedText() {
        return sharedText;
    }

    public String getLastClientLabel() {
        return lastClientLabel;
    }

    @Override
    public Response serve(IHTTPSession session) {
        noteClient(session);
        String uri = session.getUri();

        if ("/".equals(uri)) {
            return htmlResponse(loadReceiverHtml());
        }

        if ("/api/state".equals(uri)) {
            return jsonResponse(Response.Status.OK, renderStateJson());
        }

        if ("/upload".equals(uri)) {
            if (session.getMethod() != Method.POST) {
                return textResponse(Response.Status.METHOD_NOT_ALLOWED, "POST required");
            }
            return handleUpload(session);
        }

        if ("/text".equals(uri)) {
            if (session.getMethod() != Method.POST) {
                return textResponse(Response.Status.METHOD_NOT_ALLOWED, "POST required");
            }
            return handleIncomingText(session);
        }

        if ("/download-all".equals(uri)) {
            return handleDownloadAll();
        }

        if (uri != null && uri.startsWith("/file/")) {
            return handleFileDownload(uri);
        }

        if ("/health".equals(uri)) {
            return textResponse(Response.Status.OK, "Sendly OK");
        }

        return textResponse(Response.Status.NOT_FOUND, "Not found");
    }

    private Response handleFileDownload(String uri) {
        try {
            int index = Integer.parseInt(uri.substring("/file/".length()));
            SharedItem item;
            synchronized (items) {
                if (index < 0 || index >= items.size()) {
                    return textResponse(Response.Status.NOT_FOUND, "File not found");
                }
                item = items.get(index);
            }

            InputStream input = context.getContentResolver().openInputStream(item.uri);
            if (input == null) return textResponse(Response.Status.NOT_FOUND, "File unavailable");

            Listener l = listener;
            if (l != null) l.onFileRequested(item.name);
            Diagnostics.log("WEB", "Browser requested file: " + item.name);

            Response response = item.size >= 0
                    ? newFixedLengthResponse(Response.Status.OK, item.mime, input, item.size)
                    : newChunkedResponse(Response.Status.OK, item.mime, input);
            String encoded = URLEncoder.encode(item.name, StandardCharsets.UTF_8.name()).replace("+", "%20");
            response.addHeader("Content-Disposition", "attachment; filename=\"" + safeAsciiFilename(item.name)
                    + "\"; filename*=UTF-8''" + encoded);
            response.addHeader("Cache-Control", "no-store");
            response.addHeader("X-Content-Type-Options", "nosniff");
            return response;
        } catch (NumberFormatException | IOException e) {
            Diagnostics.log("WEB", "File request failed: " + e);
            return textResponse(Response.Status.INTERNAL_ERROR, "Could not open this file");
        }
    }

    private Response handleDownloadAll() {
        final List<SharedItem> snapshot;
        synchronized (items) {
            snapshot = new ArrayList<>(items);
        }
        if (snapshot.isEmpty()) {
            return textResponse(Response.Status.NOT_FOUND, "No files selected");
        }

        try {
            final PipedInputStream input = new PipedInputStream(128 * 1024);
            final PipedOutputStream output = new PipedOutputStream(input);
            Thread worker = new Thread(() -> {
                try (ZipOutputStream zip = new ZipOutputStream(output)) {
                    zip.setLevel(1);
                    Set<String> usedNames = new HashSet<>();
                    for (SharedItem item : snapshot) {
                        String entryName = uniqueZipEntryName(sanitizeZipEntryName(item.name), usedNames);
                        zip.putNextEntry(new ZipEntry(entryName));
                        try (InputStream fileInput = context.getContentResolver().openInputStream(item.uri)) {
                            if (fileInput != null) copy(fileInput, zip);
                        }
                        zip.closeEntry();
                    }
                } catch (Exception e) {
                    Diagnostics.log("WEB", "Download all ZIP failed: " + e);
                    try { output.close(); } catch (IOException ignored) { }
                }
            }, "Sendly-Zip");
            worker.setDaemon(true);
            worker.start();

            Listener l = listener;
            if (l != null) l.onFileRequested(snapshot.size() + " files");
            Diagnostics.log("WEB", "Browser requested Download all for " + snapshot.size() + " file(s)");

            Response response = newChunkedResponse(Response.Status.OK, "application/zip", input);
            response.addHeader("Content-Disposition", "attachment; filename=\"Sendly-files.zip\"");
            response.addHeader("Cache-Control", "no-store");
            response.addHeader("X-Content-Type-Options", "nosniff");
            return response;
        } catch (IOException e) {
            Diagnostics.log("WEB", "Could not start Download all ZIP: " + e);
            return textResponse(Response.Status.INTERNAL_ERROR, "Could not create ZIP");
        }
    }

    private Response handleUpload(IHTTPSession session) {
        Map<String, String> tempFiles = new HashMap<>();
        try {
            session.parseBody(tempFiles);
            String tempPath = tempFiles.get("file");
            if (tempPath == null || tempPath.isEmpty()) {
                return jsonResponse(Response.Status.BAD_REQUEST, "{\"ok\":false,\"error\":\"No file received\"}");
            }

            String encodedName = session.getHeaders().get("x-sendly-name");
            String name = encodedName == null ? "file" : URLDecoder.decode(encodedName, StandardCharsets.UTF_8.name());
            name = sanitizeIncomingFilename(name);
            String mime = session.getHeaders().get("x-sendly-mime");
            if (mime == null || mime.trim().isEmpty()) mime = "application/octet-stream";

            ReceivedFile received;
            try (InputStream input = new FileInputStream(new File(tempPath))) {
                received = saveIncomingFile(name, mime, input);
            }

            lastReceivedName = received.name;
            Listener l = listener;
            if (l != null) l.onUploadReceived(received);
            Diagnostics.log("UPLOAD", "Received " + received.name + " (" + received.size + " bytes)");

            return jsonResponse(Response.Status.OK,
                    "{\"ok\":true,\"name\":" + jsonString(received.name) + ",\"bytes\":" + received.size + "}");
        } catch (ResponseException | IOException e) {
            Diagnostics.log("UPLOAD", "Upload failed: " + e);
            return jsonResponse(Response.Status.INTERNAL_ERROR,
                    "{\"ok\":false,\"error\":" + jsonString("Upload failed: " + e.getMessage()) + "}");
        }
    }

    private Response handleIncomingText(IHTTPSession session) {
        Map<String, String> ignoredFiles = new HashMap<>();
        try {
            session.parseBody(ignoredFiles);
            String text = session.getParms().get("text");
            if (text == null) text = "";
            if (text.length() > MAX_TEXT_CHARS) {
                return jsonResponse(Response.Status.BAD_REQUEST,
                        "{\"ok\":false,\"error\":\"Text is too long\"}");
            }

            sharedText = text;
            Listener l = listener;
            if (l != null) l.onTextReceived(text);
            Diagnostics.log("TEXT", "Text received from browser; chars=" + text.length());
            return jsonResponse(Response.Status.OK, "{\"ok\":true}");
        } catch (ResponseException | IOException e) {
            Diagnostics.log("TEXT", "Text receive failed: " + e);
            return jsonResponse(Response.Status.INTERNAL_ERROR,
                    "{\"ok\":false,\"error\":" + jsonString("Text transfer failed") + "}");
        }
    }

    private ReceivedFile saveIncomingFile(String name, String mime, InputStream input) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Sendly");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);

            Uri destination = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (destination == null) throw new IOException("Could not create Downloads/Sendly item");

            long count;
            try (OutputStream output = resolver.openOutputStream(destination, "w")) {
                if (output == null) throw new IOException("Could not open output stream");
                count = copy(input, output);
            } catch (IOException e) {
                resolver.delete(destination, null, null);
                throw e;
            }

            values.clear();
            values.put(MediaStore.MediaColumns.IS_PENDING, 0);
            resolver.update(destination, values, null, null);
            return new ReceivedFile(destination, name, mime, count, System.currentTimeMillis());
        }

        File root = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (root == null) root = context.getFilesDir();
        File dir = new File(root, "Sendly");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create receive folder");
        File outputFile = uniqueFile(dir, name);
        long count;
        try (OutputStream output = new FileOutputStream(outputFile)) {
            count = copy(input, output);
        }
        Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".FileProvider", outputFile);
        return new ReceivedFile(uri, outputFile.getName(), mime, count, System.currentTimeMillis());
    }

    private static File uniqueFile(File dir, String name) {
        File candidate = new File(dir, name);
        if (!candidate.exists()) return candidate;
        String base = name;
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            base = name.substring(0, dot);
            ext = name.substring(dot);
        }
        for (int i = 2; i < 10_000; i++) {
            candidate = new File(dir, base + " (" + i + ")" + ext);
            if (!candidate.exists()) return candidate;
        }
        return new File(dir, System.currentTimeMillis() + "-" + name);
    }

    private static long copy(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[64 * 1024];
        long count = 0;
        int read;
        while ((read = input.read(buffer)) != -1) {
            output.write(buffer, 0, read);
            count += read;
        }
        output.flush();
        return count;
    }

    private void noteClient(IHTTPSession session) {
        String ua = session.getHeaders().get("user-agent");
        String label = describeUserAgent(ua);
        boolean changed = !label.equals(lastClientLabel);
        lastClientLabel = label;
        long now = System.currentTimeMillis();
        if (changed || now - lastClientLogAt > 15_000) {
            lastClientLogAt = now;
            Listener l = listener;
            if (l != null) l.onClientSeen(label);
            Diagnostics.log("WEB", "Receiver connected: " + label);
        }
    }

    private String renderStateJson() {
        StringBuilder json = new StringBuilder();
        json.append("{\"files\":[");
        synchronized (items) {
            for (int i = 0; i < items.size(); i++) {
                if (i > 0) json.append(',');
                SharedItem item = items.get(i);
                json.append("{\"id\":").append(i)
                        .append(",\"name\":").append(jsonString(item.name))
                        .append(",\"size\":").append(item.size)
                        .append(",\"sizeLabel\":").append(jsonString(humanSize(item.size)))
                        .append(",\"mime\":").append(jsonString(item.mime))
                        .append('}');
            }
        }
        json.append("],\"text\":").append(jsonString(sharedText))
                .append(",\"lastReceived\":").append(jsonString(lastReceivedName))
                .append('}');
        return json.toString();
    }

    private String loadReceiverHtml() {
        try (InputStream input = context.getResources().openRawResource(R.raw.receiver)) {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[16 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            return output.toString(StandardCharsets.UTF_8.name());
        } catch (IOException e) {
            Diagnostics.log("WEB", "Could not load receiver page: " + e);
            return "<!doctype html><title>Sendly</title><h1>Sendly</h1><p>Receiver page unavailable.</p>";
        }
    }

    private Response htmlResponse(String body) {
        Response r = newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", body);
        r.addHeader("Cache-Control", "no-store");
        r.addHeader("X-Content-Type-Options", "nosniff");
        return r;
    }

    private Response jsonResponse(Response.Status status, String body) {
        Response r = newFixedLengthResponse(status, "application/json; charset=utf-8", body);
        r.addHeader("Cache-Control", "no-store");
        return r;
    }

    private Response textResponse(Response.Status status, String body) {
        return newFixedLengthResponse(status, "text/plain; charset=utf-8", body);
    }

    public static List<String> localIpv4Addresses() {
        List<String> preferred = new ArrayList<>();
        List<String> fallback = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces == null) return preferred;
            while (interfaces.hasMoreElements()) {
                NetworkInterface nif = interfaces.nextElement();
                if (!nif.isUp() || nif.isLoopback()) continue;
                String interfaceName = nif.getName() == null ? "" : nif.getName().toLowerCase(Locale.US);
                boolean wifiLike = interfaceName.startsWith("wlan") || interfaceName.startsWith("ap")
                        || interfaceName.startsWith("swlan") || interfaceName.startsWith("wifi");
                boolean tunnelLike = interfaceName.startsWith("tun") || interfaceName.startsWith("vpn")
                        || interfaceName.startsWith("wg");
                Enumeration<InetAddress> addresses = nif.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress address = addresses.nextElement();
                    if (address instanceof Inet4Address && !address.isLoopbackAddress() && address.isSiteLocalAddress()) {
                        String host = address.getHostAddress();
                        if (wifiLike) preferred.add(host);
                        else if (!tunnelLike) fallback.add(host);
                    }
                }
            }
        } catch (Exception e) {
            Diagnostics.log("WEB", "Could not enumerate local addresses: " + e);
        }
        preferred.addAll(fallback);
        return preferred;
    }

    private static String describeUserAgent(String ua) {
        if (ua == null || ua.isEmpty()) return "Browser connected";
        String lower = ua.toLowerCase(Locale.US);
        boolean mac = lower.contains("macintosh") || lower.contains("mac os x");
        String browser;
        if (lower.contains("edg/")) browser = "Edge";
        else if (lower.contains("chrome/") || lower.contains("crios/")) browser = "Chrome";
        else if (lower.contains("firefox/") || lower.contains("fxios/")) browser = "Firefox";
        else if (lower.contains("safari/") && lower.contains("version/")) browser = "Safari";
        else browser = "browser";
        return (mac ? "Mac · " : "") + browser + " connected";
    }

    private static String sanitizeZipEntryName(String name) {
        String cleaned = name == null ? "file" : name.replace('\\', '_').replace('/', '_').trim();
        if (cleaned.isEmpty() || ".".equals(cleaned) || "..".equals(cleaned)) return "file";
        return cleaned;
    }

    private static String uniqueZipEntryName(String name, Set<String> usedNames) {
        String candidate = name;
        String base = name;
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            base = name.substring(0, dot);
            ext = name.substring(dot);
        }
        int index = 2;
        while (!usedNames.add(candidate)) {
            candidate = base + " (" + index++ + ")" + ext;
        }
        return candidate;
    }

    private static String sanitizeIncomingFilename(String name) {
        String cleaned = name.replace('/', '_').replace('\\', '_').replace('\u0000', '_').trim();
        if (cleaned.isEmpty() || ".".equals(cleaned) || "..".equals(cleaned)) return "file";
        return cleaned.length() > 180 ? cleaned.substring(0, 180) : cleaned;
    }

    private static String safeAsciiFilename(String name) {
        return name.replaceAll("[^A-Za-z0-9._ -]", "_").replace("\"", "_");
    }

    private static String jsonString(String value) {
        if (value == null) return "\"\"";
        StringBuilder out = new StringBuilder(value.length() + 16);
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"': out.append("\\\""); break;
                case '\\': out.append("\\\\"); break;
                case '\b': out.append("\\b"); break;
                case '\f': out.append("\\f"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                default:
                    if (c < 0x20) out.append(String.format(Locale.US, "\\u%04x", (int) c));
                    else out.append(c);
            }
        }
        return out.append('"').toString();
    }

    private static String humanSize(long bytes) {
        if (bytes < 0) return "Ready";
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"KB", "MB", "GB", "TB"};
        int unit = -1;
        do {
            value /= 1024.0;
            unit++;
        } while (value >= 1024 && unit < units.length - 1);
        return String.format(Locale.US, value >= 10 ? "%.0f %s" : "%.1f %s", value, units[unit]);
    }

    private static final class SharedItem {
        final Uri uri;
        final String name;
        final String mime;
        final long size;

        private SharedItem(Uri uri, String name, String mime, long size) {
            this.uri = uri;
            this.name = name;
            this.mime = mime;
            this.size = size;
        }

        static SharedItem from(Context context, Uri uri) {
            ContentResolver resolver = context.getContentResolver();
            String name = null;
            long size = -1;
            try (Cursor cursor = resolver.query(uri,
                    new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                    if (nameIndex >= 0) name = cursor.getString(nameIndex);
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex);
                }
            } catch (Exception ignored) {
            }
            if (name == null || name.trim().isEmpty()) name = uri.getLastPathSegment();
            if (name == null || name.trim().isEmpty()) name = "file";
            String mime = resolver.getType(uri);
            if (mime == null || mime.isEmpty()) mime = "application/octet-stream";
            return new SharedItem(uri, name, mime, size);
        }
    }
}
