package com.sendly.transfer;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.DocumentsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.util.ArrayList;
import java.util.List;

/** Main Sendly UI. The transfer server itself lives in SendlyConnectionService. */
public class MainActivity extends AppCompatActivity implements SendlyConnectionService.Listener,
        ReceivedFilesAdapter.Actions {

    private final List<Uri> pendingUris = new ArrayList<>();

    private TextView selectionStatus;
    private TextView serverAddress;
    private TextView connectionStatus;
    private TextView networkHint;
    private TextView backgroundStatus;
    private TextView receivedEmpty;
    private TextView receivedCount;
    private TextInputEditText clipboardText;
    private ImageView qrCode;
    private MaterialButton copyLink;
    private MaterialButton shareLink;
    private ReceivedFilesAdapter receivedAdapter;

    private SendlyConnectionService connectionService;
    private boolean serviceBound;
    private boolean selectionDirty;
    private boolean textDirty;
    private boolean suppressTextWatcher;
    private String receiverUrl;

    private final ActivityResultLauncher<Intent> picker = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    collectUris(result.getData(), true);
                }
            });

    private final ActivityResultLauncher<String> notificationPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            granted -> Diagnostics.log("SERVICE", "Notification permission granted=" + granted));

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            SendlyConnectionService.LocalBinder localBinder = (SendlyConnectionService.LocalBinder) binder;
            connectionService = localBinder.getService();
            serviceBound = true;
            connectionService.addListener(MainActivity.this);

            if (selectionDirty) {
                connectionService.setUris(pendingUris);
                selectionDirty = false;
            } else {
                pendingUris.clear();
                pendingUris.addAll(connectionService.getSharedUris());
            }

            if (textDirty) {
                CharSequence text = clipboardText.getText();
                connectionService.setSharedText(text == null ? "" : text.toString());
                textDirty = false;
            } else {
                setClipboardField(connectionService.getSharedText());
            }

            refreshUiFromService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
            connectionService = null;
            backgroundStatus.setText(R.string.background_sharing_reconnecting);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        selectionStatus = findViewById(R.id.selection_status);
        serverAddress = findViewById(R.id.server_address);
        connectionStatus = findViewById(R.id.connection_status);
        networkHint = findViewById(R.id.network_hint);
        backgroundStatus = findViewById(R.id.background_status);
        receivedEmpty = findViewById(R.id.received_empty);
        receivedCount = findViewById(R.id.received_count);
        clipboardText = findViewById(R.id.clipboard_text);
        qrCode = findViewById(R.id.qr_code);
        copyLink = findViewById(R.id.copy_link);
        shareLink = findViewById(R.id.share_link);

        RecyclerView receivedList = findViewById(R.id.received_list);
        receivedAdapter = new ReceivedFilesAdapter(this);
        receivedList.setLayoutManager(new LinearLayoutManager(this));
        receivedList.setAdapter(receivedAdapter);
        receivedList.setNestedScrollingEnabled(false);

        findViewById(R.id.add_media).setOnClickListener(v -> openPicker(true));
        findViewById(R.id.add_files).setOnClickListener(v -> openPicker(false));
        findViewById(R.id.clear_selection).setOnClickListener(v -> clearSelection());
        findViewById(R.id.use_clipboard).setOnClickListener(v -> usePhoneClipboard());
        findViewById(R.id.clear_clipboard).setOnClickListener(v -> setSharedText(""));
        findViewById(R.id.refresh_connection).setOnClickListener(v -> refreshConnectionState(true));
        findViewById(R.id.open_received_folder).setOnClickListener(v -> openSendlyFolder());
        copyLink.setOnClickListener(v -> copyReceiverLink());
        shareLink.setOnClickListener(v -> shareReceiverLink());

        clipboardText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (suppressTextWatcher) return;
                String value = s == null ? "" : s.toString();
                if (serviceBound && connectionService != null) {
                    connectionService.setSharedText(value);
                    textDirty = false;
                } else {
                    textDirty = true;
                }
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        startBackgroundConnectionService();
        requestNotificationPermissionIfNeeded();
        handleIncomingShare(getIntent());
        updateSelectionStatus();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent(this, SendlyConnectionService.class);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        if (serviceBound && connectionService != null) {
            connectionService.removeListener(this);
        }
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
            connectionService = null;
        }
        super.onStop();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingShare(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.diagnostics) {
            startActivity(new Intent(this, DiagnosticsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void startBackgroundConnectionService() {
        Intent intent = new Intent(this, SendlyConnectionService.class);
        ContextCompat.startForegroundService(this, intent);
        backgroundStatus.setText(R.string.background_sharing_active);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }

    private void openPicker(boolean mediaOnly) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        if (mediaOnly) {
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        } else {
            intent.setType("*/*");
        }
        picker.launch(Intent.createChooser(intent,
                mediaOnly ? getString(R.string.add_media) : getString(R.string.add_files)));
    }

    private void collectUris(Intent data, boolean replace) {
        if (replace) pendingUris.clear();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                addUri(clip.getItemAt(i).getUri(), data.getFlags());
            }
        } else {
            addUri(data.getData(), data.getFlags());
        }
        pushSelectionToService();
    }

    private void addUri(Uri uri, int flags) {
        if (uri == null || pendingUris.contains(uri)) return;
        pendingUris.add(uri);
        try {
            int takeFlags = flags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            if (takeFlags != 0) getContentResolver().takePersistableUriPermission(uri, takeFlags);
        } catch (Exception ignored) {
            // Share intents and some providers only grant access for the current app session.
        }
    }

    @SuppressWarnings("deprecation")
    private void handleIncomingShare(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_SEND.equals(action)) {
            Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);

            if (uri != null) {
                pendingUris.clear();
                addUri(uri, intent.getFlags());
                pushSelectionToService();
            }
            if (text != null && text.length() > 0) {
                setSharedText(text.toString());
                Toast.makeText(this, R.string.text_ready_for_mac, Toast.LENGTH_SHORT).show();
            }
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> uris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (uris != null) {
                pendingUris.clear();
                for (Uri uri : uris) addUri(uri, intent.getFlags());
                pushSelectionToService();
            }
        }
    }

    private void pushSelectionToService() {
        selectionDirty = true;
        if (serviceBound && connectionService != null) {
            connectionService.setUris(pendingUris);
            selectionDirty = false;
        }
        updateSelectionStatus();
        if (!pendingUris.isEmpty()) {
            Toast.makeText(this, R.string.open_link_on_mac, Toast.LENGTH_SHORT).show();
        }
    }

    private void clearSelection() {
        pendingUris.clear();
        pushSelectionToService();
    }

    private void updateSelectionStatus() {
        if (pendingUris.isEmpty()) {
            selectionStatus.setText(R.string.no_files_selected_modern);
        } else {
            selectionStatus.setText(getResources().getQuantityString(
                    R.plurals.files_selected_ready, pendingUris.size(), pendingUris.size()));
        }
    }

    private void refreshUiFromService() {
        if (!serviceBound || connectionService == null) return;
        receiverUrl = connectionService.getReceiverUrl();
        if (receiverUrl == null) {
            serverAddress.setText(R.string.no_local_network);
            networkHint.setText(R.string.connect_same_wifi);
            copyLink.setEnabled(false);
            shareLink.setEnabled(false);
            qrCode.setVisibility(View.GONE);
        } else {
            serverAddress.setText(receiverUrl);
            networkHint.setText(R.string.receiver_instructions_v05);
            copyLink.setEnabled(true);
            shareLink.setEnabled(true);
            showQr(receiverUrl);
        }

        String client = connectionService.getLastClientLabel();
        connectionStatus.setText(client == null ? getString(R.string.waiting_for_mac_v05) : client);
        backgroundStatus.setText(R.string.background_sharing_active);

        pendingUris.clear();
        pendingUris.addAll(connectionService.getSharedUris());
        updateSelectionStatus();
        setClipboardField(connectionService.getSharedText());
        updateReceivedFiles(connectionService.getRecentReceivedFiles());
    }

    private void showQr(String value) {
        try {
            Bitmap bitmap = createQrCode(value, 720);
            qrCode.setImageBitmap(bitmap);
            qrCode.setVisibility(View.VISIBLE);
        } catch (WriterException e) {
            qrCode.setVisibility(View.GONE);
            Diagnostics.log("QR", "QR generation failed: " + e);
        }
    }

    private static Bitmap createQrCode(String value, int size) throws WriterException {
        BitMatrix matrix = new QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, size, size);
        int[] pixels = new int[size * size];
        for (int y = 0; y < size; y++) {
            int offset = y * size;
            for (int x = 0; x < size; x++) {
                pixels[offset + x] = matrix.get(x, y) ? Color.BLACK : Color.WHITE;
            }
        }
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, size, 0, 0, size, size);
        return bitmap;
    }

    private void copyReceiverLink() {
        if (receiverUrl == null) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Sendly", receiverUrl));
        Toast.makeText(this, R.string.link_copied, Toast.LENGTH_SHORT).show();
    }

    private void shareReceiverLink() {
        if (receiverUrl == null) return;
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, receiverUrl);
        startActivity(Intent.createChooser(share, getString(R.string.share_connection_link)));
    }

    private void usePhoneClipboard() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (!clipboard.hasPrimaryClip() || clipboard.getPrimaryClip() == null
                || clipboard.getPrimaryClip().getItemCount() == 0) {
            Toast.makeText(this, R.string.clipboard_empty, Toast.LENGTH_SHORT).show();
            return;
        }

        CharSequence text = clipboard.getPrimaryClip().getItemAt(0).coerceToText(this);
        if (text == null || text.length() == 0) {
            Toast.makeText(this, R.string.clipboard_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        setSharedText(text.toString());
        Toast.makeText(this, R.string.text_ready_for_mac, Toast.LENGTH_SHORT).show();
    }

    private void setSharedText(String text) {
        setClipboardField(text);
        textDirty = true;
        if (serviceBound && connectionService != null) {
            connectionService.setSharedText(text);
            textDirty = false;
        }
    }

    private void setClipboardField(String text) {
        String value = text == null ? "" : text;
        CharSequence current = clipboardText.getText();
        if (current != null && value.contentEquals(current)) return;
        suppressTextWatcher = true;
        clipboardText.setText(value);
        clipboardText.setSelection(clipboardText.length());
        suppressTextWatcher = false;
    }

    private void refreshConnectionState(boolean toastIfMissing) {
        if (serviceBound && connectionService != null) {
            connectionService.refreshConnection();
            refreshUiFromService();
            if (toastIfMissing && connectionService.getLastClientLabel() == null) {
                Toast.makeText(this, R.string.open_receiver_first, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void updateReceivedFiles(List<ReceivedFile> files) {
        List<ReceivedFile> safe = files == null ? new ArrayList<>() : files;
        receivedAdapter.submit(safe);
        receivedEmpty.setVisibility(safe.isEmpty() ? View.VISIBLE : View.GONE);
        receivedCount.setText(getResources().getQuantityString(
                R.plurals.recent_received_count, safe.size(), safe.size()));
    }

    @Override
    public void onOpen(ReceivedFile file) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(file.uri, file.mime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, getString(R.string.open_with)));
        } catch (Exception e) {
            Toast.makeText(this, R.string.could_not_open_file, Toast.LENGTH_SHORT).show();
            Diagnostics.log("UI", "Could not open received file: " + e);
        }
    }

    @Override
    public void onLocate(ReceivedFile file) {
        openSendlyFolder();
    }

    private void openSendlyFolder() {
        Uri folder = DocumentsContract.buildDocumentUri(
                "com.android.externalstorage.documents",
                "primary:Download/Sendly"
        );
        try {
            Intent view = new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(folder, "vnd.android.document/directory");
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(view);
            return;
        } catch (Exception ignored) {
        }

        try {
            Intent pickerIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pickerIntent.addCategory(Intent.CATEGORY_OPENABLE);
            pickerIntent.setType("*/*");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                pickerIntent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, folder);
            }
            startActivity(pickerIntent);
        } catch (Exception e) {
            Toast.makeText(this, R.string.could_not_open_folder, Toast.LENGTH_SHORT).show();
            Diagnostics.log("UI", "Could not open Downloads/Sendly: " + e);
        }
    }

    @Override
    public void onServiceStateChanged() {
        runOnUiThread(this::refreshUiFromService);
    }

    @Override
    public void onFileRequested(String name) {
        runOnUiThread(() -> connectionStatus.setText(getString(R.string.downloading_on_mac, name)));
    }

    @Override
    public void onUploadReceived(ReceivedFile file) {
        runOnUiThread(() -> {
            updateReceivedFiles(connectionService == null ? null : connectionService.getRecentReceivedFiles());
            Toast.makeText(this, getString(R.string.received_to_downloads, file.name), Toast.LENGTH_LONG).show();
        });
    }

    @Override
    public void onTextReceived(String text) {
        runOnUiThread(() -> {
            setClipboardField(text);
            Toast.makeText(this, R.string.copied_to_phone_clipboard, Toast.LENGTH_SHORT).show();
        });
    }
}
