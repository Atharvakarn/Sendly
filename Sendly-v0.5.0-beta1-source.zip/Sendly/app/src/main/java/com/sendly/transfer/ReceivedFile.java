package com.sendly.transfer;

import android.net.Uri;

/** A file received from the browser and saved by Sendly. */
public final class ReceivedFile {
    public final Uri uri;
    public final String name;
    public final String mime;
    public final long size;
    public final long receivedAt;

    public ReceivedFile(Uri uri, String name, String mime, long size, long receivedAt) {
        this.uri = uri;
        this.name = name;
        this.mime = mime == null || mime.isEmpty() ? "application/octet-stream" : mime;
        this.size = size;
        this.receivedAt = receivedAt;
    }
}
