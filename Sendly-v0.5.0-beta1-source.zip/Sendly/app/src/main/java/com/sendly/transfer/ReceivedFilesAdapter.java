package com.sendly.transfer;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.text.format.DateUtils;
import android.util.Size;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Material-style recent-receives list with image/video thumbnails when available. */
public final class ReceivedFilesAdapter extends RecyclerView.Adapter<ReceivedFilesAdapter.Holder> {

    public interface Actions {
        void onOpen(ReceivedFile file);
        void onLocate(ReceivedFile file);
    }

    private static final ExecutorService THUMBNAILS = Executors.newFixedThreadPool(2);
    private final ArrayList<ReceivedFile> items = new ArrayList<>();
    private final Actions actions;

    public ReceivedFilesAdapter(Actions actions) {
        this.actions = actions;
    }

    public void submit(List<ReceivedFile> files) {
        items.clear();
        if (files != null) items.addAll(files);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_received_file, parent, false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        ReceivedFile file = items.get(position);
        holder.boundUri = file.uri.toString();
        holder.name.setText(file.name);
        holder.meta.setText(formatMeta(file));
        holder.open.setOnClickListener(v -> actions.onOpen(file));
        holder.locate.setOnClickListener(v -> actions.onLocate(file));

        boolean image = file.mime.startsWith("image/");
        boolean video = file.mime.startsWith("video/");
        int pad = Math.round(16 * holder.itemView.getResources().getDisplayMetrics().density);
        holder.thumb.setPadding(pad, pad, pad, pad);
        holder.thumb.setImageResource(image ? R.drawable.ic_image_file : video ? R.drawable.ic_video_file : R.drawable.ic_file_generic);

        if ((image || video) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Context context = holder.itemView.getContext().getApplicationContext();
            String expected = holder.boundUri;
            THUMBNAILS.execute(() -> {
                try {
                    Bitmap bitmap = context.getContentResolver().loadThumbnail(file.uri, new Size(192, 192), null);
                    holder.itemView.post(() -> {
                        if (expected.equals(holder.boundUri)) {
                            holder.thumb.setPadding(0, 0, 0, 0);
                            holder.thumb.setImageBitmap(bitmap);
                        }
                    });
                } catch (Exception ignored) {
                    // Generic icon remains visible when the provider cannot create a thumbnail.
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private static String formatMeta(ReceivedFile file) {
        String kind;
        if (file.mime.startsWith("image/")) kind = "Image";
        else if (file.mime.startsWith("video/")) kind = "Video";
        else if (file.mime.startsWith("audio/")) kind = "Audio";
        else if (file.mime.equals("application/pdf")) kind = "PDF";
        else kind = "File";
        CharSequence time = DateUtils.getRelativeTimeSpanString(
                file.receivedAt,
                System.currentTimeMillis(),
                DateUtils.MINUTE_IN_MILLIS,
                DateUtils.FORMAT_ABBREV_RELATIVE
        );
        return kind + " · " + humanSize(file.size) + " · " + time;
    }

    private static String humanSize(long bytes) {
        if (bytes < 0) return "Ready";
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"KB", "MB", "GB", "TB"};
        int unit = -1;
        do {
            value /= 1024.0;
            unit++;
        } while (value >= 1024 && unit < units.length - 1);
        return String.format(Locale.US, value >= 10 ? "%.0f %s" : "%.1f %s", value, units[unit]);
    }

    static final class Holder extends RecyclerView.ViewHolder {
        final ImageView thumb;
        final TextView name;
        final TextView meta;
        final MaterialButton open;
        final MaterialButton locate;
        String boundUri = "";

        Holder(@NonNull View itemView) {
            super(itemView);
            thumb = itemView.findViewById(R.id.received_thumbnail);
            name = itemView.findViewById(R.id.received_name);
            meta = itemView.findViewById(R.id.received_meta);
            open = itemView.findViewById(R.id.open_received);
            locate = itemView.findViewById(R.id.locate_received);
        }
    }
}
