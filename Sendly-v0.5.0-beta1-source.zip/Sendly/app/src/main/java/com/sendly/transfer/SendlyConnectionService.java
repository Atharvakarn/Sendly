package com.sendly.transfer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * Owns Sendly's local transfer server so the browser connection keeps working while
 * the Activity is backgrounded. The foreground service is intentionally scoped as a
 * connected-device service because the session is an ongoing network connection to
 * another device on the local network.
 */
public final class SendlyConnectionService extends Service implements LocalTransferServer.Listener {

    public interface Listener {
        void onServiceStateChanged();
        void onFileRequested(String name);
        void onUploadReceived(ReceivedFile file);
        void onTextReceived(String text);
    }

    public static final String ACTION_STOP = "com.sendly.transfer.action.STOP_SHARING";
    private static final String CHANNEL_ID = "sendly_connection";
    private static final int NOTIFICATION_ID = 4105;
    private static final String PREFS = "sendly_live_session";
    private static final String KEY_URIS = "shared_uris";
    private static final String KEY_TEXT = "shared_text";
    private static final String KEY_RECEIVED = "received_files";
    private static final int MAX_RECENT = 12;

    private final LocalBinder binder = new LocalBinder();
    private final CopyOnWriteArraySet<Listener> listeners = new CopyOnWriteArraySet<>();
    private final ArrayList<Uri> sharedUris = new ArrayList<>();
    private final ArrayList<ReceivedFile> recentReceived = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private LocalTransferServer server;
    private String receiverUrl;
    private String sharedText = "";
    private String lastClientLabel;
    private int activePort = LocalTransferServer.DEFAULT_PORT;

    public final class LocalBinder extends Binder {
        public SendlyConnectionService getService() {
            return SendlyConnectionService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        restoreSession();
        promoteToForeground("Starting local sharing…");
        startServerIfNeeded();
        refreshReceiverAddress();
        handler.post(addressRefresh);
        Diagnostics.log("SERVICE", "Connected-device foreground service started");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            Diagnostics.log("SERVICE", "Stop sharing requested");
            stopSelf();
            return START_NOT_STICKY;
        }
        startServerIfNeeded();
        refreshReceiverAddress();
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (server != null) {
            server.setListener(null);
            server.stop();
            server = null;
        }
        Diagnostics.log("SERVICE", "Connected-device foreground service stopped");
        super.onDestroy();
    }

    public void addListener(Listener listener) {
        if (listener != null) listeners.add(listener);
    }

    public void removeListener(Listener listener) {
        if (listener != null) listeners.remove(listener);
    }

    public void setUris(List<Uri> uris) {
        synchronized (sharedUris) {
            sharedUris.clear();
            if (uris != null) sharedUris.addAll(uris);
        }
        if (server != null) server.setUris(getSharedUris());
        persistSession();
        notifyStateChanged();
        updateNotification(lastClientLabel == null ? "Sharing is active in background" : lastClientLabel);
    }

    public List<Uri> getSharedUris() {
        synchronized (sharedUris) {
            return new ArrayList<>(sharedUris);
        }
    }

    public void setSharedText(String text) {
        sharedText = text == null ? "" : text;
        if (server != null) server.setSharedText(sharedText);
        persistSession();
        notifyStateChanged();
    }

    public String getSharedText() {
        return sharedText;
    }

    public String getReceiverUrl() {
        refreshReceiverAddress();
        return receiverUrl;
    }

    public String getLastClientLabel() {
        return lastClientLabel;
    }

    public List<ReceivedFile> getRecentReceivedFiles() {
        synchronized (recentReceived) {
            return new ArrayList<>(recentReceived);
        }
    }

    public void refreshConnection() {
        startServerIfNeeded();
        refreshReceiverAddress();
        notifyStateChanged();
    }

    public void stopSharing() {
        stopSelf();
    }

    @Override
    public void onClientSeen(String label) {
        lastClientLabel = label;
        updateNotification(label == null ? "Browser connected" : label);
        notifyStateChanged();
    }

    @Override
    public void onFileRequested(String name) {
        updateNotification("Sending " + name);
        for (Listener listener : listeners) listener.onFileRequested(name);
    }

    @Override
    public void onUploadReceived(ReceivedFile file) {
        if (file == null) return;
        synchronized (recentReceived) {
            recentReceived.add(0, file);
            while (recentReceived.size() > MAX_RECENT) recentReceived.remove(recentReceived.size() - 1);
        }
        persistSession();
        updateNotification("Received " + file.name);
        for (Listener listener : listeners) listener.onUploadReceived(file);
        notifyStateChanged();
    }

    @Override
    public void onTextReceived(String text) {
        sharedText = text == null ? "" : text;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText("Sendly", sharedText));
        }
        persistSession();
        updateNotification("Text received from browser");
        for (Listener listener : listeners) listener.onTextReceived(sharedText);
        notifyStateChanged();
    }

    private void startServerIfNeeded() {
        if (server != null) return;
        for (int port = LocalTransferServer.DEFAULT_PORT; port < LocalTransferServer.DEFAULT_PORT + 10; port++) {
            LocalTransferServer candidate = null;
            try {
                candidate = new LocalTransferServer(this, port);
                candidate.setListener(this);
                candidate.start(5000, false);
                activePort = port;
                server = candidate;
                server.setUris(getSharedUris());
                server.setSharedText(sharedText);
                Diagnostics.log("WEB", "Background local receiver started on port " + port);
                return;
            } catch (Exception e) {
                if (candidate != null) candidate.stop();
                Diagnostics.log("WEB", "Port " + port + " unavailable: " + e);
            }
        }
        Diagnostics.log("WEB", "Could not start background local receiver");
        updateNotification("Could not start local receiver");
    }

    private void refreshReceiverAddress() {
        List<String> addresses = LocalTransferServer.localIpv4Addresses();
        String next = addresses.isEmpty() ? null : "http://" + addresses.get(0) + ":" + activePort;
        if ((receiverUrl == null && next != null) || (receiverUrl != null && !receiverUrl.equals(next))) {
            receiverUrl = next;
            Diagnostics.log("WEB", "Receiver address updated: " + receiverUrl + "; addresses=" + addresses);
            notifyStateChanged();
            updateNotification(lastClientLabel == null ? "Sharing is active in background" : lastClientLabel);
        } else if (receiverUrl == null) {
            notifyStateChanged();
        }
    }

    private final Runnable addressRefresh = new Runnable() {
        @Override
        public void run() {
            refreshReceiverAddress();
            handler.postDelayed(this, 5000);
        }
    };

    private void notifyStateChanged() {
        for (Listener listener : listeners) listener.onServiceStateChanged();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Sendly connection",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Keeps local Sendly transfers available while the app is in the background");
        manager.createNotificationChannel(channel);
    }

    private Notification buildNotification(String detail) {
        Intent openIntent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this,
                0,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent stopIntent = new Intent(this, SendlyConnectionService.class).setAction(ACTION_STOP);
        PendingIntent stopPendingIntent = PendingIntent.getService(
                this,
                1,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String url = receiverUrl;
        String text = detail == null ? "Local sharing is active" : detail;
        if (url != null && !url.isEmpty() && !text.contains(url)) text += " · " + url;

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification_white_24dp)
                .setContentTitle("Sendly is ready")
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setContentIntent(contentIntent)
                .addAction(0, "Stop sharing", stopPendingIntent)
                .build();
    }

    private void promoteToForeground(String detail) {
        Notification notification = buildNotification(detail);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void updateNotification(String detail) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(detail));
    }

    private void persistSession() {
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray uris = new JSONArray();
            synchronized (sharedUris) {
                for (Uri uri : sharedUris) uris.put(uri.toString());
            }
            JSONArray received = new JSONArray();
            synchronized (recentReceived) {
                for (ReceivedFile file : recentReceived) {
                    JSONObject obj = new JSONObject();
                    obj.put("uri", file.uri.toString());
                    obj.put("name", file.name);
                    obj.put("mime", file.mime);
                    obj.put("size", file.size);
                    obj.put("time", file.receivedAt);
                    received.put(obj);
                }
            }
            prefs.edit()
                    .putString(KEY_URIS, uris.toString())
                    .putString(KEY_TEXT, sharedText)
                    .putString(KEY_RECEIVED, received.toString())
                    .apply();
        } catch (Exception e) {
            Diagnostics.log("SERVICE", "Could not persist live session: " + e);
        }
    }

    private void restoreSession() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        sharedText = prefs.getString(KEY_TEXT, "");
        try {
            JSONArray uris = new JSONArray(prefs.getString(KEY_URIS, "[]"));
            synchronized (sharedUris) {
                sharedUris.clear();
                for (int i = 0; i < uris.length(); i++) sharedUris.add(Uri.parse(uris.getString(i)));
            }
        } catch (Exception e) {
            Diagnostics.log("SERVICE", "Could not restore selected files: " + e);
        }
        try {
            JSONArray received = new JSONArray(prefs.getString(KEY_RECEIVED, "[]"));
            synchronized (recentReceived) {
                recentReceived.clear();
                for (int i = 0; i < received.length() && i < MAX_RECENT; i++) {
                    JSONObject obj = received.getJSONObject(i);
                    recentReceived.add(new ReceivedFile(
                            Uri.parse(obj.getString("uri")),
                            obj.optString("name", "file"),
                            obj.optString("mime", "application/octet-stream"),
                            obj.optLong("size", -1),
                            obj.optLong("time", System.currentTimeMillis())
                    ));
                }
            }
        } catch (Exception e) {
            Diagnostics.log("SERVICE", "Could not restore recent files: " + e);
        }
    }
}
