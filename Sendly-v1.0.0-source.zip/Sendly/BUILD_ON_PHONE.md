# Build Sendly v0.5 with GitHub Actions

No Android IDE or computer build environment is required.

1. Upload `Sendly-v1.0.0-source.zip` to the root of your GitHub repository.
2. Open `.github/workflows/build-sendly.yml` and replace its contents with the supplied v1.0 workflow.
3. Commit directly to `main`.
4. Open **Actions → Build Sendly 1.0.0 APK**.
5. Wait for the run to finish successfully.
6. Download the `Sendly-v1.0.0` artifact.
7. Extract it and install `Sendly-v1.0.0.apk` on Android.

The debug build is suitable for testing. A stable signing key should be configured before public distribution.
