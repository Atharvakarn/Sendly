# Sendly

Sendly moves files and text between Android and macOS without installing anything on the Mac.

## Sendly 1.0

1. Open Sendly on Android.
2. Open the local Sendly address in Safari, Chrome, Edge or Firefox on the Mac.
3. Transfer in either direction:
   - Android → Mac: choose files on Android, then download individual files or use **Download all** to receive one ZIP.
   - Mac → Android: drag files into the browser or choose files. They are saved to `Downloads/Sendly` on Android.
   - Android → Mac text: use the Clipboard card or Share → Sendly, then copy it on the Mac page.
   - Mac → Android text: paste/type in the Mac page and send it to the phone clipboard.
4. A QR code is shown on Android as an optional shortcut to the local browser address.

### Background connection

Sendly hosts its local receiver from an Android `connectedDevice` foreground service. The browser connection and active transfers can continue after the Sendly Activity is backgrounded. Android shows an ongoing Sendly notification with a **Stop sharing** action while the service is active.

### Recent files received from Mac

The Android home screen shows recent incoming files with:

- image/video thumbnails where Android can generate them
- file type, size and receive time
- **Open** action
- **Show in Files** / Downloads/Sendly shortcut

The recent list is retained across normal service/activity recreation.

The devices must be on the same local network. If the router isolates clients, connect the Mac to the phone hotspot instead.

No cloud upload, account, or macOS companion application is required.

### Why browser mode?

Modern AirDrop uses Apple's AWDL peer-to-peer Wi-Fi layer. Ordinary Android applications cannot reliably access or emulate that interface on typical unrooted Android hardware. Sendly uses standard local HTTP instead, which is stable across Android and macOS versions.

### Clipboard limitation

A web browser cannot monitor the whole macOS clipboard in the background. Sendly therefore uses explicit browser actions: paste text on the Mac page to send it to Android, and click Copy on the Mac page for text shared by Android. Automatic Universal Clipboard-style background sync would require a Mac helper application.

## Build

For local development:

```bash
./gradlew assembleDebug
```

The included GitHub Actions workflow builds the installable Sendly 1.0.0 APK artifact.

Sendly is an independent project and is not affiliated with Apple Inc.
