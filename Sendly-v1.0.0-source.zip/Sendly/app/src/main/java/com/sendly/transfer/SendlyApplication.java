/*
 * Copyright (C) 2019 The MoKee Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.sendly.transfer;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.sendly.transfer.certificate.CertificateManager;

public class SendlyApplication extends Application {

    private CertificateManager mCertificateManager;
    private static SendlyApplication application;

    static SendlyApplication from(Context context) {
        return (SendlyApplication) context.getApplicationContext();
    }
    static SendlyApplication getInstance() {
        return application;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        application = this;
        Diagnostics.init(this);
        installCrashLogger();
        // Browser transfer mode does not require the legacy AirDrop certificate stack.
    }

    private void installCrashLogger() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                Diagnostics.log("CRASH", "Uncaught exception on " + thread.getName() + ":\n"
                        + Log.getStackTraceString(throwable));
            } catch (Throwable ignored) {
                // Never let diagnostic logging interfere with Android's normal crash handler.
            }
            if (previous != null) {
                previous.uncaughtException(thread, throwable);
            } else {
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(10);
            }
        });
    }

    CertificateManager getCertificateManager() {
        return mCertificateManager;
    }

}
